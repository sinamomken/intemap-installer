#!/usr/bin/env python

#################
# Prepare the reads
#################

import sys
import os
from string import *

scriptdir = os.path.dirname(os.path.abspath(sys.argv[0]))

if len( sys.argv ) != 2:
    print 'Usage runrfh.py readfile'
try:
    f = file(sys.argv[1])
except:
    print '\nerror when read in readfile'
    exit()

rfheader = scriptdir+os.path.sep+'rfheader'
if not os.path.exists(rfheader):
    print 'error no rfheader', rfheader
    exit()

pairreads_ve = []
singlereads_ve = []
while True:
    line = f.readline()
    if len(line) == 0:
        break
    s = split(line)
    if len(s) == 2:
        pairreads = []
        for i in s:
            if not os.path.exists(i):
                print i, 'not found'
                exit()
            if len(os.path.split(i)[0]) == 0:
                r = os.getcwd() + os.path.sep + i
                pairreads.append( r )
            else:
                pairreads.append(i)
        pairreads_ve.append(pairreads)
        del pairreads
    elif len(s) == 1:
        for i in s:
            if not os.path.exists(i):
                print i, 'not found'
                exit()
            if len(os.path.split(i)[0]) == 0:
                r = os.getcwd() + os.path.sep + i
                singlereads_ve.append(r)
            else:
                singlereads_ve.append(i)
f.close()

rfh_pairreads_ve = []
rfh_singlereads_ve = []
#objdir = sys.argv[2]
#if not os.path.isdir( objdir ):
#    os.mkdir(objdir)

#os.chdir(objdir)

#print os.getcwd()

for p in pairreads_ve:
    rfh_pairreads = []
    for p1 in p:
        #    f = file(p1)
        #line = f.readline()
        #f.close()
        #if len(line) == 0:
        #    continue
        #s = split(line)
        #print line
        #if len(s) > 1:
        bsn = os.path.basename(p1)
        prefix = bsn[:bsn.rfind(".")]
        print prefix
        cmmd = ' '.join([rfheader, p1, prefix])
        print cmmd
        os.system(cmmd)
        nf = prefix + '_rfh.fastq'
        if not os.path.exists( nf ):
            print 'failed refheader'
            exit()
        rf = os.getcwd() + os.path.sep + nf
        rfh_pairreads.append( rf )
        #else:
        #    cmmd = ' '.join(['ln', '-s', p1, '.'])
         #   os.system(cmmd)
         #   bsn = os.path.basename(p1)
         #   rf = os.getcwd() + os.path.sep + bsn
         #   rfh_pairreads.append( rf )
    rfh_pairreads_ve.append( rfh_pairreads )
    del rfh_pairreads
for g in singlereads_ve:
    #f = file(g)
    #line = f.readline()
    #f.close()
    #if len(line) == 0:
    #    continue
    #print line
    #s = split(line)
    #if len(s) >= 1:
    bsn = os.path.basename(g)
    prefix = bsn[:bsn.rfind(".")]
    print prefix
    cmmd = '_'.join([rfheader, g, prefix])
    print cmmd
    os.system(cmmd)
    nf = prefix + '_rfh.fastq'
    if not os.path.exists( nf ):
        print 'failed refheader'
        exit()
    rf = os.getcwd() + os.path.sep + nf
    rfh_singlereads_ve.append( rf )
    #else:
     #   cmmd = ' '.join(['ln', '-s', g, '.'])
     #   os.system(cmmd)
     #   bsn = os.path.basename(g)
     #   rf = os.getcwd() + os.path.sep + bsn

exit()



