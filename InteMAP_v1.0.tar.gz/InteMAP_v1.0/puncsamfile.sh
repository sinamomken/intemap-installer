#!/bin/bash
Assemblydir=$1
allsam=${Assemblydir}/*.sam

i=0
for sam in $allsam
do
    samarray[${i}]=$sam
    i=$i+1
done

sampunc=${samarray[0]}
for ((i=1; i < ${#samarray[*]}; ++i))
do
    sampunc=${sampunc},${samarray[${i}]}
done

echo $sampunc

