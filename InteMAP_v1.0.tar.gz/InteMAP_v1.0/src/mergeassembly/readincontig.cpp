#include "readincontig.h"

void ini_Assembly_bank( string queryfile, string subjectfile, Assembly_Bank &ass_bank, string& query_name, string &subject_name )
{
	
	GetContigFromFile_1( queryfile, ass_bank.ass_query, query_name );
	GetContigFromFile_1( subjectfile, ass_bank.ass_subject, subject_name );
	
}

void GetContigFromFile_1( string filename, Assembly &ass, string& name )
{

	ass.name = name;
	ifstream inf ( filename.data() );
	if ( !inf.good() ) {
		cout<<"could not open file "<<filename<<endl;  exit(1);
	}
	string line;
	string seq;
	string id;
	getline( inf, line );

	while(!inf.eof()){
		id = line.substr(1);
		getline( inf,line );

		while ( line.find(">") == std::string::npos )              
		{
			
			seq+=line;

			if ( inf.eof() )
				break;
			getline( inf, line);
			
		}

		Contig ctg;
		ctg.name = id;
		ctg.seq = seq;
		ctg.length = (int)seq.size();

		ass.Contigs.push_back( ctg );
		
		int i = (int)ass.Contigs.size() - 1;

		ass.ctg_name_map.insert( make_pair( id, i ) );

		seq.erase( seq.begin(), seq.end() );


	}



	inf.close();

}

