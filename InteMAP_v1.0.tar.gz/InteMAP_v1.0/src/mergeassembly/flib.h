#ifndef FILB_H
#define FLIB_H

#include <vector>
#include <set>
#include <iostream>
#include <cstdlib>
#include <algorithm>
using namespace std;

bool pos_overlap( int begin_a, int end_a, int begin_b, int end_b );

bool pos_overlap( pair<int, int>, vector< pair<int, int> > & );  //if 80% of the range is occupyed, return true

bool getminusrange( pair<int, int> range, vector< pair<int, int> > & cover_v, pair<int, int> &left_range );

bool getrangegap(  pair<int, int> range, vector< pair<int, int> > & cover_v, pair<int, int> &gap );

bool pos_overlap( pair<int, int>, pair<int, int > ); // if 80% of the smaller range is overlap with the larger one, return true

bool pos_overlap_both( pair<int, int> a, pair<int, int > b );   // if the overlap occupies larger than 80% of each seg, return true

bool pos_contain( pair<int, int> a, pair<int, int> b ); // if a contain b, return true; else return false.

void mergerange( vector<pair<int, int > >& cover );

void getminusrange_wholectg( vector<pair<int, int > >& seprate_cover, int ctglen, vector<pair<int, int > > &left_range );

void getomisrange( vector<pair<int, int > >& seprate_cover, pair<int, int> total_range, vector<pair<int, int > > &left_range );

void getomisrange2( vector<pair<int, int > >& separate_cover, pair<int, int> total_range, vector<pair<int, int > > &left_range );

pair< int, double > getoverratio( pair<int, int > a, pair<int, int > b );  // return the overlap(a,b) and the ratio of overlap(a,b) / b.

pair< int, int > orderrange( pair<int, int > );


char getsuppl_base( char c );

string getsuppl_str( string &s );

#endif

