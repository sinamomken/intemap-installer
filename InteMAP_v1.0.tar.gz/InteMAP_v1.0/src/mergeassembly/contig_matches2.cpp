#include "contig_matches2.h"


int Coords::refstart()
{
	return atoi( val[0].c_str() );
}

int Coords::refend()
{
	return atoi( val[1].c_str() );
}

int Coords::qrystart()
{
	return atoi( val[2].c_str() );
}

int Coords::qryend()
{
	return atoi( val[3].c_str() );
}

int Coords::refalen()
{
	return atoi( val[4].c_str() );
}

int Coords::qryalen()
{
	return atoi( val[5].c_str() );
}

double Coords::identity()
{
	return atof( val[6].c_str() );
}

int Coords::reflen()
{
	return atoi( val[7].c_str() );
}

int Coords::qrylen()
{
	return atoi( val[8].c_str() );
}

string Coords::refname()
{
	return val[9];
}

string Coords::qryname()
{
	return val[10];
}

void Coords::reverse()
{
	vector< string > v;
	bool forward = true;
	if ( qrystart() > qryend() )
		forward = false;
	if ( forward )
		v.push_back( val[2] );
	else
		v.push_back( val[3] );
	if ( forward )
		v.push_back( val[3] );
	else
		v.push_back( val[2] );
	if ( forward )
		v.push_back( val[0] );
	else
		v.push_back( val[1] );
	if ( forward )
		v.push_back( val[1] );
	else
		v.push_back( val[0] );
	v.push_back( val[5] );
	v.push_back( val[4] );
	v.push_back( val[6] );
	v.push_back( val[8] );
	v.push_back( val[7] );
	v.push_back( val[10] );
	v.push_back( val[9] );

	val = v;
}


string Feature::Fea()
{
	return val[1];
}

string Feature::ctgname()
{
	return val[0];
}

int Feature::Feastart()
{
	return atoi( val[2].c_str() );
}

int Feature::Feaend()
{
	return atoi( val[3].c_str() );
}

int Feature::Fealen()
{
	return atoi( val[4].c_str() );
}

int Feature::GAPRlen()
{
	if ( Fea() != "GAP" ) {
		cout<<"error the feature is not 'GAP', "<<Fea()<<endl; exit(1);
	}
	return atoi( val[4].c_str() );
}

int Feature::GAPQlen()
{
	if ( Fea() != "GAP" ) {
		cout<<"error the feature is not 'GAP', "<<Fea()<<endl; exit(1);
	}
	return atoi( val[5].c_str() );
}

int Feature::GAPdiff()
{
	if ( Fea() != "GAP" ) {
		cout<<"error the feature is not 'GAP', "<<Fea()<<endl; exit(1);
	}
	return atoi( val[6].c_str() );
}

string Feature::SEQprev()
{
	if ( Fea() != "SEQ" ) {
		cout<<"error the feature is not 'SEQ', "<<Fea()<<endl; exit(1);
	}
	return val[5];

}

string Feature::SEQnext()
{
	if ( Fea() != "SEQ" ) {
		cout<<"error the feature is not 'SEQ', "<<Fea()<<endl; exit(1);
	}
	return val[6];
}


