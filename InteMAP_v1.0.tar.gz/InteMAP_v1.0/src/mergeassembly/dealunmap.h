#ifndef DEALUNMAP_H
#define DEALUNMAP_H
#include "bank.h"
#include "flib.h"
void findunmap( Ass_Mapping &amo, Assembly_Bank &ass_bank, vector<Path > &path_ve );
bool checkbreak_validate( Contig &ctg, int cutpoint );   // if break, return true, else false.
void crosssmallrep( vector< Seg > &t_seg_ve, int length, set< pair<int, int > > &merged_unmaprange );
void getunmapseg( Ctg_id i, Contig& ctg, vector< Seg > &t_seg_ve, Ass_Mapping &amo, bool subject );
void markcontainedunimapping( set< size_t > &uncontained, vector< pair<int, int > > &unimaprange, set< pair<int, int > > &merged_unmaprange );
//bool checksegpos( Seg &sg, Assembly_Bank &ass_bank );   // if in the edge 300 range return true, else return false.

class Path_Overlap
{
public:
	size_t pathleft;
	size_t pathright;
	int linkside_pathleft;    // 1 front, 0 back
	int linkside_pathright;   // 1 front, 0 back
	int ovlen;
};

void getotherpath( Path_Overlap &pob, size_t path_in, size_t& path_other, int& front_or_back_other );

void anaunmerged( Ass_Mapping &amo, Assembly_Bank &ass_bank );
void getoverlap( int pa_1, int pa_2, int pb_1, int pb_2, int& ov_1, int& ov_2 );

#endif
