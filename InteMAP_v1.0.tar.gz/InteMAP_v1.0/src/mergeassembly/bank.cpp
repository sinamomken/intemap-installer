#include "bank.h"
/*
void Alignment_Bank::ini_bank( Assembly_Bank &ass_bank )
{
	for ( size_t i = 0; i < ass_bank.ass_ve.size(); ++i )
	{
		vector< map< pair<int, int>, vector<size_t> > > ccm;
		for ( Ctg_id c = 0; c < (int)ass_bank.ass_ve[i].Contigs.size(); ++c )
		{
			map< pair<int, int>, vector<size_t> > cm;
			ccm.push_back( cm );
		}
		cor_align_map.push_back( ccm );
	}
}

int Alignment::get_subj_start()
{
	return coordinate[0];
}

int Alignment::get_subj_end()
{
	return coordinate[1];
}

int Alignment::get_qury_start()
{
	return coordinate[2];
}

int Alignment::get_qury_end()
{
	return coordinate[3];
}

int Alignment::get_subj_start_from_ctg()
{
	return min( get_subj_start(), get_subj_end() );
}

int Alignment::get_subj_end_from_ctg()
{
	return max( get_subj_start(), get_subj_end() );
}

int Alignment::get_qury_start_from_ctg()
{
	return min( get_qury_start(), get_qury_end() );
}

int Alignment::get_qury_end_from_ctg()
{
	return max( get_qury_start(), get_qury_end() );
}

bool Alignment::qury_fw()
{
	if ( get_qury_start() < get_qury_end() )
		return true;
	else
		return false;
}

int Alignment::get_align_len()
{
	int nega_offset = 0;
	for ( size_t i = 0; i < offset.size(); ++i )
	{
		if ( offset[i] < 0 )
			nega_offset += 1;
	}
	return get_subj_end() - get_subj_start() + 1 + nega_offset;
}

pair<bool, bool> Alignment::self_trim()
{
	bool subj_change = false;
	bool qury_change = false;
	if ( !offset.empty() )
	{
		while ( offset[0] == 1 || offset[0] == -1 )
		{
			if ( offset[0] == 1 )
			{
				coordinate[0]+=1;
				subj_change = true;
			} else if ( offset[0] == -1 )
			{
				if ( qury_fw() )
					coordinate[2]+=1;
				else
					coordinate[2]-=1;

				qury_change = true;
			}
		
			vector<int > newoffset;
			vector<int>::iterator oi = offset.begin();
			++oi;
			newoffset.insert( newoffset.end(), oi, offset.end() );
			offset = newoffset;
		//	cout<<"after trim: "<<coordinate[0]<<","<<coordinate[1]<<","<<coordinate[2]<<","<<coordinate[3]<<endl;
			if ( offset.empty() )
				break;
		}

		if ( offset.empty() )
			return make_pair( subj_change, qury_change );

		bool goon = false;
		do {
			
			int lastindpos = 0;
			
			for ( size_t i = 0; i < offset.size(); ++i )
			{
				if ( offset[i] > 0 )
				{
					
					lastindpos += offset[i];
				} else
				{
					
					lastindpos += (-1)*offset[i];
				}
			}

			if ( lastindpos == get_align_len() )
			{
				
				if ( offset.back() > 0 )
				{
					coordinate[1] -= 1;
					subj_change = true;
				} else
				{
					if ( qury_fw() )
						coordinate[3] -= 1;
					else
						coordinate[3] += 1;
					qury_change = true;
				}

			

				offset.pop_back();
			//	cout<<"after trim: "<<coordinate[0]<<","<<coordinate[1]<<","<<coordinate[2]<<","<<coordinate[3]<<endl;
				if ( offset.empty() )
					break;

				goon = true;
			}
		} while ( goon );
	}

	return make_pair( subj_change, qury_change );
}

bool Single_Segment::fw()
{
	if ( start < end )
		return true;
	else
		return false;
}

bool Single_Segment::single_base()
{
	if ( start == end )
		return true;
	else
		return false;
}

double Single_Segment::getDUPscore()
{
	
	if ( DUP.empty() )
		return 0;

	set< size_t > allcomp = DUP;
	if ( !bone_seg.empty() )
	{
		for ( map< size_t, pair< int, int > >::iterator ite = bone_seg.begin(); ite != bone_seg.end(); ++ite )
			allcomp.insert( ite->first );
	}

	return 1.0 * (double)DUP.size() / ((double)allcomp.size() + 1.0 );
}

int Shared_Segment::get_subord_seg_start( size_t subord_ass )
{
	if ( subord_seg.find( subord_ass ) == subord_seg.end() )
	{
		cout<<"warning shard_segment does not contain the subord_ass: "<<subord_ass<<endl;
		return -1;
	}
	return subord_seg[subord_ass].start;
}

int Shared_Segment::get_subord_seg_end( size_t subord_ass )
{
	if ( subord_seg.find( subord_ass ) == subord_seg.end() )
	{
		cout<<"warning shard_segment does not contain the subord_ass: "<<subord_ass<<endl;
		return -1;
	}
	return subord_seg[subord_ass].end;
}

Ctg_id Shared_Segment::get_subord_seg_ctgid( size_t subord_ass )
{
	if ( subord_seg.find( subord_ass ) == subord_seg.end() )
	{
		cout<<"warning shard_segment does not contain the subord_ass: "<<subord_ass<<endl;
		return -1;
	}
	return subord_seg[subord_ass].ctg_id;
}

bool Shared_Segment::get_subord_seg_fw( size_t subord_ass )
{
	if ( subord_seg.find( subord_ass ) == subord_seg.end() )
	{
		cout<<"warning shard_segment does not contain the subord_ass: "<<subord_ass<<endl;
		exit(1);
	}
	return subord_seg[subord_ass].fw();
}

int Segment_Bank::get_seg_begin( S_seg_id seg_id, size_t ord_ass )
{
	if ( seg_id >= S_seg.size() )
	{
		cout<<"error seg_id "<<seg_id<<endl; exit(1);
	}
	return S_seg[seg_id].get_subord_seg_start( ord_ass );

}

int Segment_Bank::get_seg_end( S_seg_id seg_id, size_t ord_ass )
{
	if ( seg_id >= S_seg.size() )
	{
		cout<<"error seg_id "<<seg_id<<endl; exit(1);
	}
	return S_seg[seg_id].get_subord_seg_end( ord_ass );
}

int Segment_Bank::get_seg_begin_from_ctg( S_seg_id seg_id, size_t ord_ass )
{
	if ( get_seg_fw( seg_id, ord_ass ) )
		return get_seg_begin( seg_id, ord_ass );
	else
		return get_seg_end( seg_id, ord_ass );
}

int Segment_Bank::get_seg_end_from_ctg( S_seg_id seg_id, size_t ord_ass )
{
	if ( get_seg_fw( seg_id, ord_ass ) )
		return get_seg_end( seg_id, ord_ass );
	else
		return get_seg_begin( seg_id, ord_ass );
}

Ctg_id Segment_Bank::get_seg_ctg_id( S_seg_id seg_id, size_t ord_ass  )
{
	if ( seg_id >= S_seg.size() )
	{
		cout<<"error seg_id "<<seg_id<<endl; exit(1);
	}
	return S_seg[seg_id].get_subord_seg_ctgid( ord_ass );
}

bool Segment_Bank::get_seg_fw( S_seg_id seg_id, size_t ord_ass )
{
	if ( seg_id >= S_seg.size() )
	{
		cout<<"error seg_id "<<seg_id<<endl; exit(1);
	}
	return S_seg[seg_id].get_subord_seg_fw( ord_ass );
}

void Segment_Bank::get_cover_chain( size_t ass_id, Ctg_id ctg_id, pair<int, int> range, list< pair<int, int> >& cut_range, list< S_seg_id >& cover_seg )
{
	if ( ass_ord_seg_chain.find( ass_id ) == ass_ord_seg_chain.end() )
	{
		cout<<"error seg_chain does not find ass "<<ass_id<<endl; exit(1);
	}
	if ( ass_ord_seg_chain[ass_id].find( ctg_id ) == ass_ord_seg_chain[ass_id].end() )
	{
		cout<<"error seg_chain["<<ass_id<<"] does not find ctg "<<ctg_id<<endl; exit(1);
	}

	int stat = 0;
	list< S_seg_id >::iterator sli;
	for ( sli = ass_ord_seg_chain[ass_id][ctg_id].S_seg_list.begin(); sli != ass_ord_seg_chain[ass_id][ctg_id].S_seg_list.end(); ++sli )
	{
		if ( S_seg[*sli].subord_seg.find( ass_id ) == S_seg[*sli].subord_seg.end() )
		{
			cout<<"error in get_cover_chain: wrong seg "<<*sli<<" in chain ass"<<ass_id<<" ctg"<<ctg_id<<endl; exit(1);
		}
		if ( stat == 0 )
		{
			
			if ( get_seg_end_from_ctg( *sli, ass_id ) < range.first )
				continue;
			else 
			{
				if ( get_seg_end_from_ctg( *sli, ass_id ) < range.second )
				{
					cut_range.push_back( make_pair( max( range.first, get_seg_begin_from_ctg( *sli, ass_id ) ), get_seg_end_from_ctg( *sli, ass_id ) ) );
					cover_seg.push_back( *sli );
					stat = 1;
				} else if ( get_seg_begin_from_ctg( *sli, ass_id ) < range.second ) {
					cut_range.push_back( make_pair( max( range.first, get_seg_begin_from_ctg( *sli, ass_id ) ), range.second ) );
					cover_seg.push_back( *sli );
					break;
				} else
					break;
			}
			
		} else if ( stat == 1 )
		{
			if ( get_seg_begin_from_ctg( *sli, ass_id ) <= range.first )
			{
				cut_range.clear();
				cover_seg.clear();

				if ( get_seg_end_from_ctg( *sli, ass_id ) < range.first )
				{
					cout<<"error position "<<get_seg_end_from_ctg( *sli, ass_id )<<" "<<range.first<<endl; 
					cout<<"ass "<<ass_id <<" ctg "<<ctg_id<<endl;
					for ( list< S_seg_id >::iterator ii = ass_ord_seg_chain[ass_id][ctg_id].S_seg_list.begin();
						ii != ass_ord_seg_chain[ass_id][ctg_id].S_seg_list.end(); ++ii )
					{
						cout<<get_seg_begin_from_ctg( *ii, ass_id )<<" "<<get_seg_end_from_ctg( *ii, ass_id )<<" "<<*ii<<endl;
					}
					exit(1);
				}

				if ( get_seg_end_from_ctg( *sli, ass_id ) < range.second )
				{
					cut_range.push_back( make_pair( max( range.first, get_seg_begin_from_ctg( *sli, ass_id ) ), get_seg_end_from_ctg( *sli, ass_id ) ) );
					cover_seg.push_back( *sli );
				} else {
					cut_range.push_back( make_pair( max( range.first, get_seg_begin_from_ctg( *sli, ass_id ) ), range.second ) );
					cover_seg.push_back( *sli );
					break;
				}
			} else 
			{
				if ( get_seg_end_from_ctg( *sli, ass_id ) < range.second )
				{
					cut_range.push_back( make_pair( get_seg_begin_from_ctg( *sli, ass_id ), get_seg_end_from_ctg( *sli, ass_id ) ) );
					cover_seg.push_back( *sli );
				} else if ( get_seg_begin_from_ctg( *sli, ass_id ) <= range.second ) {
					cut_range.push_back( make_pair( get_seg_begin_from_ctg( *sli, ass_id ), range.second ) );
					
					cover_seg.push_back( *sli );
					break;
				} else
					break;
			}
		}
	}

}

bool Segment_Bank::fringe( S_seg_id seg_id, size_t ass_id, int site )
{
	if ( seg_id >= S_seg.size() )
	{
		cout<<"error seg_id "<<seg_id<<endl; exit(1);
	}
	if ( S_seg[seg_id].get_subord_seg_start( ass_id ) == site || S_seg[seg_id].get_subord_seg_end( ass_id ) == site )
		return true;
	else
		return false;
}

bool Segment_Bank::begin_fringe_from_ctg( S_seg_id seg_id, size_t ass_id, int site )
{
	if ( get_seg_begin_from_ctg( seg_id, ass_id ) == site )
		return true;
	else
		return false;
}

bool Segment_Bank::end_fringe_from_ctg( S_seg_id seg_id, size_t ass_id, int site )
{
	if ( get_seg_end_from_ctg( seg_id, ass_id ) == site )
		return true;
	else
		return false;
}

int Shared_Segment::getsubordnumber()
{
	return (int)subord_seg.size();
}

int Shared_Segment::getlength()
{
	if ( get_subord_seg_fw( subord_seg.begin()->first ) )
		return get_subord_seg_end( subord_seg.begin()->first ) - get_subord_seg_start( subord_seg.begin()->first ) + 1;
	else
		return get_subord_seg_start( subord_seg.begin()->first ) - get_subord_seg_end( subord_seg.begin()->first ) + 1;
}

double Shared_Segment::getDUPscore()
{
	if ( rep )
		return 0;
	double sc = 0;
	for ( map< size_t, Single_Segment >::iterator ite = subord_seg.begin(); ite != subord_seg.end(); ++ite )
	{
		sc += ite->second.getDUPscore();
	}
	double s = sc / (double)subord_seg.size();
	return s;
}

void showseg( Shared_Segment &seg, ofstream& outf)
{
	if ( seg.subord_seg.empty() )
		return;
	outf<<seg.getsubordnumber()<<" "<<seg.getlength();
	if ( seg.rep )
		outf<<" rep";
	else
		outf<<" DUPscore "<<seg.getDUPscore();
	outf<<endl;
	map< size_t, Single_Segment >::iterator si;
	for ( si = seg.subord_seg.begin(); si != seg.subord_seg.end(); ++si )
	{
		outf<<si->first<<" "<<si->second.ctg_id<<" "<<si->second.start<<" "<<si->second.end<<" DUPsc "<<si->second.getDUPscore();
		map< size_t, pair< int, int > >::iterator bi;
		for ( bi = si->second.bone_seg.begin(); bi != si->second.bone_seg.end(); ++bi )
		{
			outf<<"("<<bi->first<<" "<<bi->second.first<<" "<<bi->second.second<<")";
		}
		outf<<endl;
	}
}

bool base_equal( char a, char b )
{
	if ( a == b )
		return true;

	if ( ( a == 'A' || a == 'a' ) && ( b == 'A' || b == 'a' ) )
		return true;
	if ( ( a == 'T' || a == 't' ) && ( b == 'T' || b == 't' ) )
		return true;
	if ( ( a == 'C' || a == 'c' ) && ( b == 'C' || b == 'c' ) )
		return true;
	if ( ( a == 'G' || a == 'g' ) && ( b == 'G' || b == 'g' ) )
		return true;

	return false;
}
*/


