#include "bank.h"
#include <fstream>
#include <iostream>

void ini_Assembly_bank( string queryfile, string subjectfile, Assembly_Bank &ass_bank, string& query_name, string &subject_name );

// get contig name and length
void GetContigFromFile_1( string filename, Assembly &ass, string& name );

