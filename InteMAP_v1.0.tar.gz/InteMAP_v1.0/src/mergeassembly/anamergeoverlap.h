#ifndef ANAMERGEOVERLAP_H
#define ANAMERGEOVERLAP_H
#include "bank.h"
#include "flib.h"



void anaoverlap( Ass_Mapping &amo, Assembly_Bank &ass_bank );

#endif
