#ifndef READVALIDATE_H
#define READVALIDATE_H
#include "bank.h"

void readinfea( string &infile, Assembly &ass );

void readin_100rupfw( string &infile, Assembly &ass );

void readin_100ruprv( string &infile, Assembly &ass );

void readinvalidate( string subject, string query, Assembly_Bank &ass_bank );

#endif

