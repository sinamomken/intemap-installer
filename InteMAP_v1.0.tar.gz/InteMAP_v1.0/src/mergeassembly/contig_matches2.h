#ifndef CONTIG_MATCHES2_H
#define CONTIG_MATCHES2_H

#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <cstdlib>
using namespace std;


class Coords
{
public:
	vector< string > val;

	int refstart();
	int refend();
	int qrystart();
	int qryend();
	int refalen();
	int qryalen();
	double identity();
	int reflen();
	int qrylen();
	string refname();
	string qryname();
	
	void reverse();
};



class Feature
{
public:
	vector< string > val;

	string Fea();
	string ctgname();
	int Feastart();
	int Feaend();
	int Fealen();
	int GAPRlen();
	int GAPQlen();
	int GAPdiff();
	string SEQprev();
	string SEQnext();

};

#endif
