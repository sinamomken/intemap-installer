#ifndef READMAPPINGS_H
#define READMAPPINGS_H
#include <iostream>
#include <fstream>
#include "bank.h"
#include <algorithm>

void readmcoordfile( string refname, string qryname, Ass_Mapping &map_o, vector< Coords >& con_mcoove );

void readcoords( string filename, vector< Coords >& coo_ve );
/*
void readmummerfiles( string refname, string qryname, Ass_Map_Bank &map_bank, Assembly_Bank &ass_bank, Alignment_Bank &ali_bank );



bool equalcoord( Coords &coo_a, Coords &coo_b );

void get_1coo( Assembly &refass, Assembly &qryass, Ass_Mapping& map_o, vector< Coords > &mcoords, vector< Coords > & _1coo_ve );

struct cmpCoordqry :
	public binary_function< Coo_ite, Coo_ite, bool >
{
	bool operator () ( Coo_ite a, Coo_ite b )
	{
		return min(a->qrystart(), a->qryend() ) >= min( b->qrystart(), b->qryend() );
	}
};

void sortCoordqry( vector< Coo_ite >& );

void readFeature( string& filename, Assembly &ass, map< Ctg_id, Ctg_Features > &fea );

void readunalign( string &filename, Assembly &ass, set<Ctg_id>& unalin );

void showcoord( Ctg_id id_a, Ctg_id id_b, map< Ctg_id, map< Ctg_id, vector< Coords > > > &coomap );
void showcoord( Coords &coo );
void outputcoord( Coords &coo, ofstream &outf );

void transcoord( map< Ctg_id, map< Ctg_id, vector< Coo_ite > > > &mapa, map< Ctg_id, map< Ctg_id, vector< Coords > > > &mapb, vector< Coords > &ve );
*/

#endif
