#include "dealunmap.h"

void findunmap( Ass_Mapping &amo, Assembly_Bank &ass_bank, vector<Path > &path_ve )
{
	ofstream logf("findunmapLog");
	vector< Seg > ref_seg_ve;
	vector< size_t > unmap_refctg_ve;
	set< Coords_id > contained_coo;
	map< Coords_id, pair< Seg_id, int > > ref_in_coo_map;     // < , <set, in_or_out> >   1, in; 0 out
	map< Coords_id, pair< Seg_id, int > > ref_out_coo_map;    // < , <seg, in_or_out> >
	for ( size_t i = 0; i < ass_bank.ass_subject.Contigs.size(); ++i )
	{
		
		
		
		logf<<">ref "<<ass_bank.ass_subject.Contigs[i].name<<endl;
		if ( ass_bank.ass_subject.Contigs[i].uni_mapping_range.empty() )
		{
			logf<<"unmap ctg"<<endl;
			unmap_refctg_ve.push_back( i );
			continue;
		}

		vector< Seg > t_seg_ve;
		getunmapseg( i, ass_bank.ass_subject.Contigs[i], t_seg_ve, amo, true );
		if ( t_seg_ve.empty() )
			continue;
		set< pair<int, int > > merged_unmaprange;
		crosssmallrep( t_seg_ve, ass_bank.ass_subject.Contigs[i].length, merged_unmaprange );
		logf<<"merged_unmaprange:";
		for ( set< pair<int, int > >::iterator ite = merged_unmaprange.begin(); ite != merged_unmaprange.end(); ++ite )
		{
			logf<<" ("<<ite->first<<","<<ite->second<<")";
		}
		logf<<endl;
		set< size_t > uncontainedunimap;
		markcontainedunimapping( uncontainedunimap, ass_bank.ass_subject.Contigs[i].uni_mapping_range, merged_unmaprange );
		if ( uncontainedunimap.empty() )
		{
			logf<<"unmap ctg(unimap contained)"<<endl;
			unmap_refctg_ve.push_back( i );
			for ( size_t u = 0; u < ass_bank.ass_subject.Contigs[i].uni_mapping_range.size(); ++u )
			{
				pair< int, int > frontrg = ass_bank.ass_subject.Contigs[i].uni_mapping_range[u];
				Coords_id coo = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( frontrg )->second;
				contained_coo.insert( coo );
			}
			continue;
		}

		size_t u = 0;
		while ( uncontainedunimap.find( u ) == uncontainedunimap.end() )
		{
			if ( u >= ass_bank.ass_subject.Contigs[i].uni_mapping_range.size() )
			{
				cout<<"error 888 "<<u<<endl; exit(1);
			}
			pair< int, int > trg = ass_bank.ass_subject.Contigs[i].uni_mapping_range[u];
			Coords_id tc = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( trg )->second;
			contained_coo.insert( tc );
			++u;
		}
		pair< int, int > frontrg = ass_bank.ass_subject.Contigs[i].uni_mapping_range[u];
		
	//	vector< pair<int, int > >::iterator ite = ass_bank.ass_subject.Contigs[i].uni_mapping_range.begin();
	//	vector< bool >::iterator bkite = ass_bank.ass_subject.Contigs[i].break_by_validate.begin();
	//	pair<int, int > frontrg = *ite;
	//	Coords_id coo = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( *ite )->second;
		Coords_id coo = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( frontrg )->second;
		if ( frontrg.first > 50 )
		{
			Seg sg;
			sg.subject = true;
			sg.ctg = i;
			sg.start = 1;
			sg.end = frontrg.first-1;
			Seg_id sid = ref_seg_ve.size();
			ref_seg_ve.push_back( sg );
			
			logf<<"frontumseg "<<sid<<" "<<sg.start<<" "<<sg.end<<endl;
			if ( amo.out_avail_coo.find( coo ) != amo.out_avail_coo.end() )
			{
				if ( ass_bank.ass_subject.Contigs[i].good_protect )
				{ 
					logf<<"good_protect"<<endl;
					ref_out_coo_map.insert( make_pair( coo, make_pair( sid, 1 ) ) );
					logf<<"link ref_out "<<coo<<" "<<sid<<" 1"<<endl;
				} else
				{
					if ( ass_bank.ass_subject.Contigs[i].repeat.find( frontrg ) == ass_bank.ass_subject.Contigs[i].repeat.end() )
					{
					
						logf<<"check break backlink"<<endl;
						if ( !checkbreak_validate( ass_bank.ass_subject.Contigs[i], sg.end ) )
						{
							ref_out_coo_map.insert( make_pair( coo, make_pair( sid, 1 ) ) );
							logf<<"link ref_out "<<coo<<" "<<sid<<" 1"<<endl;
						}
					}
				}
			}
		}
		
		for ( ; u < ass_bank.ass_subject.Contigs[i].uni_mapping_range.size();  )
	//	for ( ; ite != ass_bank.ass_subject.Contigs[i].uni_mapping_range.end(); ++ite )
		{
			size_t secu = u;
			++secu;
			if ( secu == ass_bank.ass_subject.Contigs[i].uni_mapping_range.size() )
				break;
			while ( uncontainedunimap.find( secu ) == uncontainedunimap.end() )
			{
				
				pair< int, int > trg = ass_bank.ass_subject.Contigs[i].uni_mapping_range[secu];
				Coords_id tc = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( trg )->second;
				contained_coo.insert( tc );
				++secu;
				if ( secu == ass_bank.ass_subject.Contigs[i].uni_mapping_range.size() )
				{
					
					break;
				}
			}
			if ( secu == ass_bank.ass_subject.Contigs[i].uni_mapping_range.size() )
			{
				
				break;
			}
			frontrg = ass_bank.ass_subject.Contigs[i].uni_mapping_range[u];
			Coords_id frontcoo = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( frontrg )->second;
			pair< int, int > nextrg = ass_bank.ass_subject.Contigs[i].uni_mapping_range[secu];
			Coords_id nextcoo = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( nextrg )->second;
		//	vector< pair<int, int > >::iterator secite = ite;
		//	++secite;
		//	if ( secite == ass_bank.ass_subject.Contigs[i].uni_mapping_range.end() )
		//		break;
		//	frontrg = *ite;
		//	Coords_id frontcoo = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( *ite )->second;
		//	pair< int, int > nextrg = *secite;
		//	Coords_id nextcoo = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( *secite )->second;
			int start = frontrg.second + 1;
			int end = nextrg.first - 1;
			if ( end - start + 1 >= 50 )
			{
				bool um = false;
				if ( amo.in_avail_coo.find( frontcoo ) != amo.in_avail_coo.end() || amo.out_avail_coo.find( nextcoo ) != amo.out_avail_coo.end() )
					um = true;
				else if ( ass_bank.ass_subject.Contigs[i].break_by_validate[u] )
					um = true;
				else if ( ass_bank.ass_subject.Contigs[i].uni_mapping_coo.find( frontrg ) == ass_bank.ass_subject.Contigs[i].uni_mapping_coo.end() ||
					ass_bank.ass_subject.Contigs[i].uni_mapping_coo.find( nextrg ) == ass_bank.ass_subject.Contigs[i].uni_mapping_coo.end() )
					um = true;
				bool tried_link = false;
				if ( end-start+1 < 400 )
					tried_link = true;
				if ( um )
				{
					Seg sg;
					sg.subject = true;
					sg.ctg = i;
					sg.start = start;
					sg.end = end;
					Seg_id sid = ref_seg_ve.size();
					ref_seg_ve.push_back( sg );
					
					logf<<"middleumseg "<<sid<<" "<<sg.start<<" "<<sg.end<<endl;
					if ( ass_bank.ass_subject.Contigs[i].good_protect )
					{
						logf<<"good protect"<<endl;
						if ( amo.in_avail_coo.find( frontcoo ) != amo.in_avail_coo.end() )
						{
							ref_in_coo_map.insert( make_pair( frontcoo, make_pair( sid, 0 ) ) );
							logf<<"link ref_in "<<frontcoo<<" "<<sid<<" 0"<<endl;
						} 
						if ( amo.out_avail_coo.find( nextcoo ) != amo.out_avail_coo.end() )
						{
							ref_out_coo_map.insert( make_pair( nextcoo, make_pair( sid, 1 ) ) );
							logf<<"link ref_out "<<nextcoo<<" "<<sid<<" 1"<<endl;
						}
					} else
					{
						if ( !tried_link )
						{
							if ( amo.in_avail_coo.find( frontcoo ) != amo.in_avail_coo.end() )
							{
								if ( ass_bank.ass_subject.Contigs[i].repeat.find( frontrg ) == ass_bank.ass_subject.Contigs[i].repeat.end() )
								{
									logf<<"check break frontlink"<<endl;
									if ( !checkbreak_validate( ass_bank.ass_subject.Contigs[i], sg.start ) )
									{
										ref_in_coo_map.insert( make_pair( frontcoo, make_pair( sid, 0 ) ) );
										logf<<"link ref_in "<<frontcoo<<" "<<sid<<" 0"<<endl;
									}
								}
							}
							if ( amo.out_avail_coo.find( nextcoo ) != amo.out_avail_coo.end() )
							{
								if ( ass_bank.ass_subject.Contigs[i].repeat.find( nextrg ) == ass_bank.ass_subject.Contigs[i].repeat.end() )
								{
									logf<<"check break backlink"<<endl;
									if ( !checkbreak_validate( ass_bank.ass_subject.Contigs[i], sg.end ) )
									{
										ref_out_coo_map.insert( make_pair( nextcoo, make_pair( sid, 1 ) ) );
										logf<<"link ref_out "<<nextcoo<<" "<<sid<<" 1"<<endl;
									}
								}
							}
						}
					}
				}
			}
			u = secu;
		}

		frontrg = ass_bank.ass_subject.Contigs[i].uni_mapping_range[u];
		coo = ass_bank.ass_subject.Contigs[i].mapping.lower_bound( frontrg )->second;
		if ( ass_bank.ass_subject.Contigs[i].length - frontrg.second >= 50 )
		{
			Seg sg;
			sg.subject = true;
			sg.ctg = i;
			sg.start = frontrg.second + 1;
			sg.end = ass_bank.ass_subject.Contigs[i].length;
			Seg_id sid = ref_seg_ve.size();
			ref_seg_ve.push_back( sg );
			
			logf<<"backumseg "<<sid<<" "<<sg.start<<" "<<sg.end<<endl;
			if ( amo.in_avail_coo.find( coo ) != amo.in_avail_coo.end() )
			{
				if ( ass_bank.ass_subject.Contigs[i].good_protect )
				{
					logf<<"good protect"<<endl;
					ref_in_coo_map.insert( make_pair( coo, make_pair( sid, 0 ) ) );
					logf<<"link ref_in "<<coo<<" "<<sid<<" 0"<<endl;
				} else
				{
					if ( ass_bank.ass_subject.Contigs[i].repeat.find( frontrg ) == ass_bank.ass_subject.Contigs[i].repeat.end() )
					{
						logf<<"check break frontlink"<<endl;
						if ( !checkbreak_validate( ass_bank.ass_subject.Contigs[i], sg.start ) )
						{
							ref_in_coo_map.insert( make_pair( coo, make_pair( sid, 0 ) ) );
							logf<<"link ref_in "<<coo<<" "<<sid<<" 0"<<endl;
						}
					}
				}
			}
		}



	}

	vector< Seg > qry_seg_ve;
	vector< size_t > unmap_qryctg_ve;
	map< Coords_id, pair< Seg_id, int > > qry_in_coo_map;
	map< Coords_id, pair< Seg_id, int > > qry_out_coo_map;   // <, <seg, in_or_out > >  in 1, out 0
	for ( size_t i = 0; i < ass_bank.ass_query.Contigs.size(); ++i )
	{
		logf<<">qry "<<ass_bank.ass_query.Contigs[i].name<<endl;
		
		if ( ass_bank.ass_query.Contigs[i].uni_mapping_range.empty() )
		{
			logf<<"unmap ctg"<<endl;
			unmap_qryctg_ve.push_back( i );
			continue;
		}

		vector< Seg > t_seg_ve;
		getunmapseg( i, ass_bank.ass_query.Contigs[i], t_seg_ve, amo, false );
		if ( t_seg_ve.empty() )
			continue;
		set< pair<int, int > > merged_unmaprange;
		crosssmallrep( t_seg_ve, ass_bank.ass_query.Contigs[i].length, merged_unmaprange );
		logf<<"merged_unmaprange:";
		for ( set< pair<int, int > >::iterator ite = merged_unmaprange.begin(); ite != merged_unmaprange.end(); ++ite )
		{
			logf<<" ("<<ite->first<<","<<ite->second<<")";
		}
		logf<<endl;
		set< size_t > uncontainedunimap;
		markcontainedunimapping( uncontainedunimap, ass_bank.ass_query.Contigs[i].uni_mapping_range, merged_unmaprange );
		if ( uncontainedunimap.empty() )
		{
			logf<<"unmap ctg(contained unimap)"<<endl;
			unmap_qryctg_ve.push_back( i );
			for ( size_t u = 0; u < ass_bank.ass_query.Contigs[i].uni_mapping_range.size(); ++u )
			{
				pair< int, int > frontrg = ass_bank.ass_query.Contigs[i].uni_mapping_range[u];
				Coords_id coo = ass_bank.ass_query.Contigs[i].mapping.lower_bound( frontrg )->second;
				contained_coo.insert( coo );
			}
			continue;
		}

		size_t u = 0;
		while ( uncontainedunimap.find( u ) == uncontainedunimap.end() )
		{
			if ( u >= ass_bank.ass_query.Contigs[i].uni_mapping_range.size() )
			{
				cout<<"error 898 "<<u<<endl; exit(1);
			}
			pair< int, int > trg = ass_bank.ass_query.Contigs[i].uni_mapping_range[u];
			Coords_id tc = ass_bank.ass_query.Contigs[i].mapping.lower_bound( trg )->second;
			contained_coo.insert( tc );
			++u;
		}
		
		pair<int, int > frontrg = ass_bank.ass_query.Contigs[i].uni_mapping_range[u];
		Coords_id coo = ass_bank.ass_query.Contigs[i].mapping.lower_bound( frontrg )->second;
	//	vector< pair<int, int > >::iterator ite = ass_bank.ass_query.Contigs[i].uni_mapping_range.begin();
	//	vector< bool >::iterator bkite = ass_bank.ass_query.Contigs[i].break_by_validate.begin();
	//	pair<int, int > frontrg = *ite;
	//	Coords_id coo = ass_bank.ass_query.Contigs[i].mapping.lower_bound( *ite )->second;
		bool forward = true;
		if ( amo.mcoords[coo].qryend() < amo.mcoords[coo].qrystart() )
			forward = false;
		if ( frontrg.first > 50 )
		{

			Seg sg;
			sg.subject = false;
			sg.ctg = i;
			sg.start = 1;
			sg.end = frontrg.first-1;
			Seg_id sid = qry_seg_ve.size();
			qry_seg_ve.push_back( sg );
			logf<<"frontumseg "<<sid<<" "<<sg.start<<" "<<sg.end<<endl;
			if ( ass_bank.ass_query.Contigs[i].good_protect )
			{
				if ( forward )
				{
					if ( amo.out_avail_coo.find( coo ) != amo.out_avail_coo.end() )
					{
						qry_out_coo_map.insert( make_pair( coo, make_pair( sid, 1 ) ) );
						logf<<"link qry_out "<<coo<<" "<<sid<<" 1"<<endl;
					}
				} else
				{
					if ( amo.in_avail_coo.find( coo ) != amo.in_avail_coo.end() )
					{
						qry_in_coo_map.insert( make_pair( coo, make_pair( sid, 1 ) ) );
						logf<<"link qry_in "<<coo<<" "<<sid<<" 1"<<endl;
					}
				}
			} else
			{
				if ( ass_bank.ass_query.Contigs[i].repeat.find( frontrg ) == ass_bank.ass_query.Contigs[i].repeat.end() )
				{
				
					if ( !checkbreak_validate( ass_bank.ass_query.Contigs[i], sg.end ) )
					{
						if ( forward )
						{
							if ( amo.out_avail_coo.find( coo ) != amo.out_avail_coo.end() )
							{
								qry_out_coo_map.insert( make_pair( coo, make_pair( sid, 1 ) ) );
								logf<<"link qry_out "<<coo<<" "<<sid<<" 1"<<endl;
							}
						} else
						{
							if ( amo.in_avail_coo.find( coo ) != amo.in_avail_coo.end() )
							{
								qry_in_coo_map.insert( make_pair( coo, make_pair( sid, 1 ) ) );
								logf<<"link qry_in "<<coo<<" "<<sid<<" 1"<<endl;
							}
						}
					}
				}
			}
		}
		
		for ( ; u < ass_bank.ass_query.Contigs[i].uni_mapping_range.size();  )
	//	for ( ; ite != ass_bank.ass_query.Contigs[i].uni_mapping_range.end(); ++ite )
		{
			size_t secu = u;
			++secu;
			if ( secu == ass_bank.ass_query.Contigs[i].uni_mapping_range.size() )
				break;
			while ( uncontainedunimap.find( secu ) == uncontainedunimap.end() )
			{
				
				pair< int, int > trg = ass_bank.ass_query.Contigs[i].uni_mapping_range[secu];
				Coords_id tc = ass_bank.ass_query.Contigs[i].mapping.lower_bound( trg )->second;
				contained_coo.insert( tc );
				++secu;
				if ( secu == ass_bank.ass_query.Contigs[i].uni_mapping_range.size() )
				{
					break;
				}
			}
			if ( secu == ass_bank.ass_query.Contigs[i].uni_mapping_range.size() )
				break;
			frontrg = ass_bank.ass_query.Contigs[i].uni_mapping_range[u];
			Coords_id frontcoo = ass_bank.ass_query.Contigs[i].mapping.lower_bound( frontrg )->second;
			pair< int, int > nextrg = ass_bank.ass_query.Contigs[i].uni_mapping_range[secu];
			Coords_id nextcoo = ass_bank.ass_query.Contigs[i].mapping.lower_bound( nextrg )->second;

		//	vector<pair<int, int > >::iterator secite = ite;
		//	++secite;
		//	if ( secite == ass_bank.ass_query.Contigs[i].uni_mapping_range.end() )
		//		break;
		//	frontrg = *ite;
		//	Coords_id frontcoo = ass_bank.ass_query.Contigs[i].mapping.lower_bound( *ite )->second;;
			bool frontforward = true;
			if ( amo.mcoords[frontcoo].qryend() < amo.mcoords[frontcoo].qrystart() )
				frontforward = false;
		//	pair< int, int > nextrg = *secite;
		//	Coords_id nextcoo = ass_bank.ass_query.Contigs[i].mapping.lower_bound( *secite )->second;;
			bool nextforward = true;
			if ( amo.mcoords[nextcoo].qryend() < amo.mcoords[nextcoo].qrystart() )
				nextforward = false;
			int start = frontrg.second + 1;
			int end = nextrg.first - 1;
			
			if ( end - start + 1 >= 50 )
			{
				bool um = false;
				if ( ass_bank.ass_query.Contigs[i].break_by_validate[u] )
					um = true;
				else if ( ass_bank.ass_query.Contigs[i].uni_mapping_coo.find( frontrg ) == ass_bank.ass_query.Contigs[i].uni_mapping_coo.end() ||
					ass_bank.ass_query.Contigs[i].uni_mapping_coo.find( nextrg ) == ass_bank.ass_query.Contigs[i].uni_mapping_coo.end() )
					um = true;
				else 
				{
					if ( frontforward )
					{
						if ( amo.in_avail_coo.find( frontcoo ) != amo.in_avail_coo.end() )
						{
							um = true;
						}
					} else
					{
						if ( amo.out_avail_coo.find( frontcoo ) != amo.out_avail_coo.end() )
						{
							um = true;
						}
					}
					if ( nextforward )
					{
						if ( amo.out_avail_coo.find( nextcoo ) != amo.out_avail_coo.end() )
						{
							um = true;
						}
					} else
					{
						if ( amo.in_avail_coo.find( nextcoo ) != amo.in_avail_coo.end() )
							um = true;
					}
				}

				bool tried_link = false;
				if ( end-start+1 < 400 )
					tried_link = true;
				
				if ( um )
				{
					Seg sg;
					sg.subject = false;
					sg.ctg = i;
					sg.start = start;
					sg.end = end;
					Seg_id sid = qry_seg_ve.size();
					qry_seg_ve.push_back( sg );
					logf<<"middleumseg "<<sid<<" "<<sg.start<<" "<<sg.end<<endl;
					if ( ass_bank.ass_query.Contigs[i].good_protect )
					{
						logf<<"good protect"<<endl;
						if ( frontforward )
						{
							if ( amo.in_avail_coo.find( frontcoo ) != amo.in_avail_coo.end() )
							{
								qry_in_coo_map.insert( make_pair( frontcoo, make_pair( sid, 0 ) ) );
								logf<<"link qry_in "<<frontcoo<<" "<<sid<<" 0"<<endl;
							}
						} else
						{
							if ( amo.out_avail_coo.find( frontcoo ) != amo.out_avail_coo.end() )
							{
								qry_out_coo_map.insert( make_pair( frontcoo, make_pair( sid, 0 ) ) );
								logf<<"link qry_out "<<frontcoo<<" "<<sid<<" 0"<<endl;
							}
						} 
						if ( nextforward )
						{
							if ( amo.out_avail_coo.find( nextcoo ) != amo.out_avail_coo.end() )
							{
								qry_out_coo_map.insert( make_pair( nextcoo, make_pair( sid, 1 ) ) );
								logf<<"link qry_out "<<nextcoo<<" "<<sid<<" 1"<<endl;
							}
						} else
						{
							if ( amo.in_avail_coo.find( nextcoo ) != amo.in_avail_coo.end() )
							{
								qry_in_coo_map.insert( make_pair( nextcoo, make_pair( sid, 1 ) ) );
								logf<<"link qry_in "<<nextcoo<<" "<<sid<<" 1"<<endl;
							}
						}
					} else
					{
						if ( !tried_link )
						{
							if ( ass_bank.ass_query.Contigs[i].repeat.find( frontrg ) == ass_bank.ass_query.Contigs[i].repeat.end() )
							{
								if ( !checkbreak_validate( ass_bank.ass_query.Contigs[i], sg.start ) )
								{
									if ( frontforward )
									{
										if ( amo.in_avail_coo.find( frontcoo ) != amo.in_avail_coo.end() )
										{
											qry_in_coo_map.insert( make_pair( frontcoo, make_pair( sid, 0 ) ) );
											logf<<"link qry_in "<<frontcoo<<" "<<sid<<" 0"<<endl;
										} else
											logf<<"front failed avail"<<endl;
									} else
									{
										if ( amo.out_avail_coo.find( frontcoo ) != amo.out_avail_coo.end() )
										{
											qry_out_coo_map.insert( make_pair( frontcoo, make_pair( sid, 0 ) ) );
											logf<<"link qry_out "<<frontcoo<<" "<<sid<<" 0"<<endl;
										}else
											logf<<"failed avail"<<endl;
									} 
								} else
									logf<<"front failed validate"<<endl;
							} else
								logf<<"front failed repeat"<<endl;
							if ( ass_bank.ass_query.Contigs[i].repeat.find( nextrg ) == ass_bank.ass_query.Contigs[i].repeat.end() )
							{
								if ( !checkbreak_validate( ass_bank.ass_query.Contigs[i], sg.end ) )
								{
									if ( nextforward )
									{
										if ( amo.out_avail_coo.find( nextcoo ) != amo.out_avail_coo.end() )
										{
											qry_out_coo_map.insert( make_pair( nextcoo, make_pair( sid, 1 ) ) );
											logf<<"link qry_out "<<nextcoo<<" "<<sid<<" 1"<<endl;
										}else
											logf<<"next failed avail"<<endl;
									} else
									{
										if ( amo.in_avail_coo.find( nextcoo ) != amo.in_avail_coo.end() )
										{
											qry_in_coo_map.insert( make_pair( nextcoo, make_pair( sid, 1 ) ) );
											logf<<"link qry_in "<<nextcoo<<" "<<sid<<" 1"<<endl;
										}else
											logf<<"next failed avail"<<endl;
									}
								} else
									logf<<"next failed validate"<<endl;
							}else
								logf<<"next failed repeat"<<endl;
						} else
							logf<<"failed tried"<<endl;
					}
				}
			}
			u = secu;
		//	++bkite;
		}

		
		frontrg = ass_bank.ass_query.Contigs[i].uni_mapping_range[u];
		coo = ass_bank.ass_query.Contigs[i].mapping.lower_bound( frontrg )->second;
	//	frontrg = *ite;
	//	coo = ass_bank.ass_query.Contigs[i].mapping.lower_bound( *ite )->second;;
		forward = true;
		if ( amo.mcoords[coo].qryend() < amo.mcoords[coo].qrystart() )
			forward = false;
		if ( ass_bank.ass_query.Contigs[i].length - frontrg.second >= 50 )
		{
			Seg sg;
			sg.subject = false;
			sg.ctg = i;
			sg.start = frontrg.second + 1;
			sg.end = ass_bank.ass_query.Contigs[i].length;
			Seg_id sid = qry_seg_ve.size();
			qry_seg_ve.push_back( sg );
			logf<<"backumseg "<<sid<<" "<<sg.start<<" "<<sg.end<<endl;
			if ( ass_bank.ass_query.Contigs[i].good_protect )
			{
				if ( forward )
				{
					if ( amo.in_avail_coo.find( coo ) != amo.in_avail_coo.end() )
					{
						qry_in_coo_map.insert( make_pair( coo, make_pair( sid, 0 ) ) );
						logf<<"link qry_in "<<coo<<" "<<sid<<" 0"<<endl;
					}
				} else
				{
					if ( amo.out_avail_coo.find ( coo ) != amo.out_avail_coo.end() )
					{
						qry_out_coo_map.insert( make_pair( coo, make_pair( sid, 0 ) ) );
						logf<<"link qry_out "<<coo<<" "<<sid<<" 0"<<endl;
					}
				}
			} else
			{
				if ( ass_bank.ass_query.Contigs[i].repeat.find( frontrg ) == ass_bank.ass_query.Contigs[i].repeat.end() )
				{
					if ( !checkbreak_validate( ass_bank.ass_query.Contigs[i], sg.start ) )
					{
						if ( forward )
						{
							if ( amo.in_avail_coo.find( coo ) != amo.in_avail_coo.end() )
							{
								qry_in_coo_map.insert( make_pair( coo, make_pair( sid, 0 ) ) );
								logf<<"link qry_in "<<coo<<" "<<sid<<" 0"<<endl;
							}
						} else
						{
							if ( amo.out_avail_coo.find ( coo ) != amo.out_avail_coo.end() )
							{
								qry_out_coo_map.insert( make_pair( coo, make_pair( sid, 0 ) ) );
								logf<<"link qry_out "<<coo<<" "<<sid<<" 0"<<endl;
							}
						}
					}
				}
			}
		}

	}

	// find out contradict link
	set< Coords_id > contr_in_coo;
	set< Coords_id > contr_out_coo;
	for ( map< Coords_id, pair< Seg_id, int > >::iterator ite = ref_in_coo_map.begin(); ite != ref_in_coo_map.end(); ++ite )
	{
		if ( qry_in_coo_map.find( ite->first ) != qry_in_coo_map.end() )
			contr_in_coo.insert( ite->first );
	}
	for (map< Coords_id, pair< Seg_id, int > >::iterator ite = ref_out_coo_map.begin(); ite != ref_out_coo_map.end(); ++ite )
	{
		if ( qry_out_coo_map.find( ite->first ) != qry_out_coo_map.end() )
			contr_out_coo.insert( ite->first );
	}

	ofstream contrf("contr");
	for ( set< Coords_id >::iterator ite = contr_in_coo.begin(); ite != contr_in_coo.end(); ++ite )
	{
		contrf<<"in: "<<*ite<<endl;
	}
	for ( set< Coords_id >::iterator ite = contr_out_coo.begin(); ite != contr_out_coo.end(); ++ite )
	{
		contrf<<"out: "<<*ite<<endl;
	}

	//erase contradict link
	for ( set< Coords_id >::iterator ite = contr_in_coo.begin(); ite != contr_in_coo.end(); ++ite )
	{
		ref_in_coo_map.erase( *ite );
		qry_in_coo_map.erase( *ite );
	}
	for ( set< Coords_id >::iterator ite = contr_out_coo.begin(); ite != contr_out_coo.end(); ++ite )
	{
		ref_out_coo_map.erase( *ite );
		qry_out_coo_map.erase( *ite );
	}

	if ( (int)amo.iPath_ve.size() != (int)path_ve.size() )
	{
		cout<<"error path number "<<amo.iPath_ve.size()<<", "<<path_ve.size()<<endl; exit(1);
	}
	// add link
	set< Seg_id > added_ref_seg;
	set< Seg_id > added_qry_seg;
	map< Seg_id, pair< size_t, int > > ref_seg_in_link; // <path_id, front_or_back>  1 front, 0 back
	map< Seg_id, pair< size_t, int > > ref_seg_out_link; // <>
	map< Seg_id, pair< size_t, int > > qry_seg_in_link; // <path_id, front_or_back>  1 front, 0 back
	map< Seg_id, pair< size_t, int > > qry_seg_out_link; // <>
	for ( map< Coords_id, pair< Seg_id, int > >::iterator ite = ref_in_coo_map.begin(); ite != ref_in_coo_map.end(); ++ite )
	{
		if ( qry_in_coo_map.find( ite->first ) != qry_in_coo_map.end() )
		{
			cout<<"error contrdict "<<ite->first<<endl; exit(1);
		}
		if ( amo.in_avail_coo.find( ite->first ) == amo.in_avail_coo.end() )
		{
			cout<<"error in_avail_coo no find "<<ite->first<<endl; exit(1);
		}
		size_t path_id = amo.in_avail_coo[ite->first].first;
		int back_or_front = amo.in_avail_coo[ite->first].second;
		Seg_id sid = ite->second.first;
		int in_or_out = ite->second.second;
		int ctgstart = ref_seg_ve[sid].start;
		int ctgend = ref_seg_ve[sid].end;
		logf<<"addunmap begin C"<<ite->first<<" ref_in "<<sid<<" "<<in_or_out<<endl;
		string addseq = ass_bank.ass_subject.Contigs[ref_seg_ve[sid].ctg].seq.substr( ctgstart-1, ctgend-ctgstart+1 );
		
		if ( back_or_front == 1 )   // front
		{
			bool rule = false;
			bool ori_check = false;
			if ( amo.iPath_ve[path_id].Tile_list.size() <= 2 )
				ori_check = true;
			else
			{
				if ( amo.iPath_ve[path_id].Tile_list.front().subject_ori )
					ori_check = true;
			}
			if ( ori_check )
			{
			/*	if ( amo.iPath_ve[path_id].Tile_list.front().pos_iPath.second - amo.iPath_ve[path_id].Tile_list.front().pos_iPath.first+1 >= 300 )
				{
					if ( ctgend-ctgstart+1 >= 300)
						rule = true;
				}*/
				rule = true;
			}
			if ( rule )
			{
				if ( in_or_out == 1 ) //in
				{
					ref_seg_in_link.insert( make_pair( sid, make_pair( path_id, 1 ) ) );
					amo.iPath_ve[path_id].seq.insert( 0, addseq );
					Tile tile;
					tile.ctg = ref_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgstart, ctgend );
					tile.subject_ori = true;
					tile.match = false;
					int frontpos = amo.iPath_ve[path_id].Tile_list.begin()->pos_iPath.first;
					tile.pos_iPath = make_pair( frontpos-(ctgend-ctgstart+1), frontpos-1 );
					amo.iPath_ve[path_id].Tile_list.push_front( tile );
					added_ref_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add ref_seg_in_link "<<sid<<" "<<path_id<<" 1"<<endl;
				
				} else   // out
				{
					ref_seg_out_link.insert( make_pair( sid, make_pair( path_id, 1 ) ) );
					string tra_seq = getsuppl_str( addseq );
					amo.iPath_ve[path_id].seq.insert( 0, tra_seq );
					Tile tile;
					tile.ctg = ref_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgend, ctgstart );
					tile.subject_ori = true;
					tile.match = false;
					int frontpos = amo.iPath_ve[path_id].Tile_list.begin()->pos_iPath.first;
					tile.pos_iPath = make_pair( frontpos-(ctgend-ctgstart+1), frontpos-1 );
					amo.iPath_ve[path_id].Tile_list.push_front( tile );
					added_ref_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add ref_seg_out_link "<<sid<<" "<<path_id<<" 1"<<endl;
				}
			}
		} else   // back
		{
			bool rule = false;
			bool ori_check = false;
			if ( amo.iPath_ve[path_id].Tile_list.size() <= 2 )
				ori_check = true;
			else
			{
				if ( amo.iPath_ve[path_id].Tile_list.back().subject_ori )
					ori_check = true;
			}
			if ( ori_check )
			{
			/*	if ( amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second - amo.iPath_ve[path_id].Tile_list.back().pos_iPath.first+1 >= 300 )
				{
					if ( ctgend-ctgstart+1 >= 300)
						rule = true;
				}  */
				rule = true;
			}
			if ( rule )
			{
				if ( in_or_out == 1 )
				{
					ref_seg_in_link.insert( make_pair( sid, make_pair( path_id, 0 ) ) );
					string tra_seq = getsuppl_str( addseq );
					amo.iPath_ve[path_id].seq.insert( amo.iPath_ve[path_id].seq.size(), tra_seq );
					Tile tile;
					tile.ctg = ref_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgend, ctgstart );
					tile.subject_ori = true;
					tile.match = false;
					int backpos = amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second;
					tile.pos_iPath = make_pair( backpos+1, backpos+(ctgend-ctgstart+1) );
					amo.iPath_ve[path_id].Tile_list.push_back( tile );
					added_ref_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add ref_seg_in_link "<<sid<<" "<<path_id<<" 0"<<endl;
				} else
				{
					ref_seg_out_link.insert( make_pair( sid, make_pair( path_id, 0 ) ) );
					amo.iPath_ve[path_id].seq.insert( amo.iPath_ve[path_id].seq.size(), addseq );
					Tile tile;
					tile.ctg = ref_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgstart, ctgend );
					tile.subject_ori = true;
					tile.match = false;
					int backpos = amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second;
					tile.pos_iPath = make_pair( backpos+1, backpos+(ctgend-ctgstart+1) );
					amo.iPath_ve[path_id].Tile_list.push_back( tile );
					added_ref_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add ref_seg_out_link "<<sid<<" "<<path_id<<" 0"<<endl;
				}
			}
		}
	}
	for ( map< Coords_id, pair< Seg_id, int > >::iterator ite = ref_out_coo_map.begin(); ite != ref_out_coo_map.end(); ++ite )
	{
		if ( qry_out_coo_map.find( ite->first ) != qry_out_coo_map.end() )
		{
			cout<<"error contrdict "<<ite->first<<endl; exit(1);
		}
		if ( amo.out_avail_coo.find( ite->first ) == amo.out_avail_coo.end() )
		{
			cout<<"error out_avail_coo no find "<<ite->first<<endl; exit(1);
		}
		size_t path_id = amo.out_avail_coo[ite->first].first;
		int back_or_front = amo.out_avail_coo[ite->first].second;
		Seg_id sid = ite->second.first;
		int in_or_out = ite->second.second;
		int ctgstart = ref_seg_ve[sid].start;
		int ctgend = ref_seg_ve[sid].end;
		logf<<"addunmap begin C"<<ite->first<<" ref_out "<<sid<<" "<<in_or_out<<endl;
		string addseq = ass_bank.ass_subject.Contigs[ref_seg_ve[sid].ctg].seq.substr( ctgstart-1, ctgend-ctgstart+1 );
		
		if ( back_or_front == 1 )   // front
		{
			bool rule = false;
			bool ori_check = false;
			if ( amo.iPath_ve[path_id].Tile_list.size() <= 2 )
				ori_check = true;
			else
			{
				if ( amo.iPath_ve[path_id].Tile_list.front().subject_ori )
					ori_check = true;
			}
			if ( ori_check )
			{
			/*	if ( amo.iPath_ve[path_id].Tile_list.front().pos_iPath.second - amo.iPath_ve[path_id].Tile_list.front().pos_iPath.first+1 >= 300 )
				{
					if ( ctgend-ctgstart+1 >= 300)
						rule = true;
				} */
				rule = true;
			}
			if ( rule )
			{
				if ( in_or_out == 1 ) //in
				{
					ref_seg_in_link.insert( make_pair( sid, make_pair( path_id, 1 ) ) );
					amo.iPath_ve[path_id].seq.insert( 0, addseq );
					Tile tile;
					tile.ctg = ref_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgstart, ctgend );
					tile.subject_ori = true;
					tile.match = false;
					int frontpos = amo.iPath_ve[path_id].Tile_list.begin()->pos_iPath.first;
					tile.pos_iPath = make_pair( frontpos-(ctgend-ctgstart+1), frontpos-1 );
					amo.iPath_ve[path_id].Tile_list.push_front( tile );
					added_ref_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add ref_seg_in_link "<<sid<<" "<<path_id<<" 1"<<endl;
				} else   // out
				{
					ref_seg_out_link.insert( make_pair( sid, make_pair( path_id, 1 ) ) );
					string tra_seq = getsuppl_str( addseq );
					amo.iPath_ve[path_id].seq.insert( 0, tra_seq );
					Tile tile;
					tile.ctg = ref_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgend, ctgstart );
					tile.subject_ori = true;
					tile.match = false;
					int frontpos = amo.iPath_ve[path_id].Tile_list.begin()->pos_iPath.first;
					tile.pos_iPath = make_pair( frontpos-(ctgend-ctgstart+1), frontpos-1 );
					amo.iPath_ve[path_id].Tile_list.push_front( tile );
					added_ref_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add ref_seg_out_link "<<sid<<" "<<path_id<<" 1"<<endl;
				}
			}
		} else   // back
		{
			bool rule = false;
			bool ori_check = false;
			if ( amo.iPath_ve[path_id].Tile_list.size() <= 2 )
				ori_check = true;
			else
			{
				if ( amo.iPath_ve[path_id].Tile_list.back().subject_ori )
					ori_check = true;
			}
			if ( ori_check )
			{
			/*	if ( amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second - amo.iPath_ve[path_id].Tile_list.back().pos_iPath.first+1 >= 300 )
				{
					if ( ctgend-ctgstart+1 >= 300)
						rule = true;
				}  */
				rule = true;
			}
			if ( rule )
			{
				if ( in_or_out == 1 )
				{
					ref_seg_in_link.insert( make_pair( sid, make_pair( path_id, 0 ) ) );
					string tra_seq = getsuppl_str( addseq );
					amo.iPath_ve[path_id].seq.insert( amo.iPath_ve[path_id].seq.size(), tra_seq );
					Tile tile;
					tile.ctg = ref_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgend, ctgstart );
					tile.subject_ori = true;
					tile.match = false;
					int backpos = amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second;
					tile.pos_iPath = make_pair( backpos+1, backpos+(ctgend-ctgstart+1) );
					amo.iPath_ve[path_id].Tile_list.push_back( tile );
					added_ref_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add ref_seg_in_link "<<sid<<" "<<path_id<<" 0"<<endl;
				} else
				{
					ref_seg_out_link.insert( make_pair( sid, make_pair( path_id, 0 ) ) );
					amo.iPath_ve[path_id].seq.insert( amo.iPath_ve[path_id].seq.size(), addseq );
					Tile tile;
					tile.ctg = ref_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgstart, ctgend );
					tile.subject_ori = true;
					tile.match = false;
					int backpos = amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second;
					tile.pos_iPath = make_pair( backpos+1, backpos+(ctgend-ctgstart+1) );
					amo.iPath_ve[path_id].Tile_list.push_back( tile );
					added_ref_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add ref_seg_out_link "<<sid<<" "<<path_id<<" 0"<<endl;
				}
			}
		}
	}

	for ( map< Coords_id, pair< Seg_id, int > >::iterator ite = qry_in_coo_map.begin(); ite != qry_in_coo_map.end(); ++ite )
	{
		if ( ref_in_coo_map.find( ite->first ) != ref_in_coo_map.end() )
		{
			cout<<"error contrdict "<<ite->first<<endl; exit(1);
		}
		if ( amo.in_avail_coo.find( ite->first ) == amo.in_avail_coo.end() )
		{
			cout<<"error in_avail_coo no find "<<ite->first<<endl; exit(1);
		}
		size_t path_id = amo.in_avail_coo[ite->first].first;
		int back_or_front = amo.in_avail_coo[ite->first].second;
		Seg_id sid = ite->second.first;
		int in_or_out = ite->second.second;
		int ctgstart = qry_seg_ve[sid].start;
		int ctgend = qry_seg_ve[sid].end;
		logf<<"addunmap begin C"<<ite->first<<" qry_in "<<sid<<" "<<in_or_out<<endl;
		string addseq = ass_bank.ass_query.Contigs[qry_seg_ve[sid].ctg].seq.substr( ctgstart-1, ctgend-ctgstart+1 );
		
		if ( back_or_front == 1 )   // front
		{
			bool rule = false;
			bool ori_check = false;
			if ( amo.iPath_ve[path_id].Tile_list.size() <= 2 )
				ori_check = true;
			else
			{
				if ( !amo.iPath_ve[path_id].Tile_list.front().subject_ori )
					ori_check = true;
			}
			if ( ori_check )
			{
			/*	if ( amo.iPath_ve[path_id].Tile_list.front().pos_iPath.second - amo.iPath_ve[path_id].Tile_list.front().pos_iPath.first+1 >= 300 )
				{
					if ( ctgend-ctgstart+1 >= 300)
						rule = true;
				} */
				rule = true;
			}
			if ( rule )
			{
				if ( in_or_out == 1 ) //in
				{
					qry_seg_in_link.insert( make_pair( sid, make_pair( path_id, 1 ) ) );
					amo.iPath_ve[path_id].seq.insert( 0, addseq );
					Tile tile;
					tile.ctg = qry_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgstart, ctgend );
					tile.subject_ori = false;
					tile.match = false;
					int frontpos = amo.iPath_ve[path_id].Tile_list.begin()->pos_iPath.first;
					tile.pos_iPath = make_pair( frontpos-(ctgend-ctgstart+1), frontpos-1 );
					amo.iPath_ve[path_id].Tile_list.push_front( tile );
					added_qry_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_query.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add qry_seg_in_link "<<sid<<" "<<path_id<<" 1"<<endl;
				} else   // out
				{
					qry_seg_out_link.insert( make_pair( sid, make_pair( path_id, 1 ) ) );
					string tra_seq = getsuppl_str( addseq );
					amo.iPath_ve[path_id].seq.insert( 0, tra_seq );
					Tile tile;
					tile.ctg = qry_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgend, ctgstart );
					tile.subject_ori = false;
					tile.match = false;
					int frontpos = amo.iPath_ve[path_id].Tile_list.begin()->pos_iPath.first;
					tile.pos_iPath = make_pair( frontpos-(ctgend-ctgstart+1), frontpos-1 );
					amo.iPath_ve[path_id].Tile_list.push_front( tile );
					added_qry_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_query.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add qry_seg_out_link "<<sid<<" "<<path_id<<" 1"<<endl;
				}
			}
		} else   // back
		{
			bool rule = false;
			bool ori_check = false;
			if ( amo.iPath_ve[path_id].Tile_list.size() <= 2 )
				ori_check = true;
			else
			{
				if ( !amo.iPath_ve[path_id].Tile_list.back().subject_ori )
					ori_check = true;
			}
			if ( ori_check )
			{
			/*	if ( amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second - amo.iPath_ve[path_id].Tile_list.back().pos_iPath.first+1 >= 300 )
				{
					if ( ctgend-ctgstart+1 >= 300)
						rule = true;
				}  */
				rule = true;
			}
			if ( rule )
			{
				if ( in_or_out == 1 )
				{
					qry_seg_in_link.insert( make_pair( sid, make_pair( path_id, 0 ) ) );
					string tra_seq = getsuppl_str( addseq );
					amo.iPath_ve[path_id].seq.insert( amo.iPath_ve[path_id].seq.size(), tra_seq );
					Tile tile;
					tile.ctg = qry_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgend, ctgstart );
					tile.subject_ori = false;
					tile.match = false;
					int backpos = amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second;
					tile.pos_iPath = make_pair( backpos+1, backpos+(ctgend-ctgstart+1) );
					amo.iPath_ve[path_id].Tile_list.push_back( tile );
					added_qry_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_query.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add qry_seg_in_link "<<sid<<" "<<path_id<<" 0"<<endl;
				} else
				{
					qry_seg_out_link.insert( make_pair( sid, make_pair( path_id, 0 ) ) );
					amo.iPath_ve[path_id].seq.insert( amo.iPath_ve[path_id].seq.size(), addseq );
					Tile tile;
					tile.ctg = qry_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgstart, ctgend );
					tile.subject_ori = false;
					tile.match = false;
					int backpos = amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second;
					tile.pos_iPath = make_pair( backpos+1, backpos+(ctgend-ctgstart+1) );
					amo.iPath_ve[path_id].Tile_list.push_back( tile );
					added_qry_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_query.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add qry_seg_out_link "<<sid<<" "<<path_id<<" 0"<<endl;
				}
			}
		}
	}
	for ( map< Coords_id, pair< Seg_id, int > >::iterator ite = qry_out_coo_map.begin(); ite != qry_out_coo_map.end(); ++ite )
	{
		if ( ref_out_coo_map.find( ite->first ) != ref_out_coo_map.end() )
		{
			cout<<"error contrdict "<<ite->first<<endl; exit(1);
		}
		if ( amo.out_avail_coo.find( ite->first ) == amo.out_avail_coo.end() )
		{
			cout<<"error out_avail_coo no find "<<ite->first<<endl; exit(1);
		}
		
		size_t path_id = amo.out_avail_coo[ite->first].first;
		int back_or_front = amo.out_avail_coo[ite->first].second;
		Seg_id sid = ite->second.first;
		int in_or_out = ite->second.second;
		int ctgstart = qry_seg_ve[sid].start;
		int ctgend = qry_seg_ve[sid].end;
		string addseq = ass_bank.ass_query.Contigs[qry_seg_ve[sid].ctg].seq.substr( ctgstart-1, ctgend-ctgstart+1 );
		added_qry_seg.insert( sid );
		logf<<"addunmap begin C"<<ite->first<<" qry_out "<<sid<<" "<<in_or_out<<endl;
		if ( back_or_front == 1 )   // front
		{
			bool rule = false;
			bool ori_check = false;
			if ( amo.iPath_ve[path_id].Tile_list.size() <= 2 )
				ori_check = true;
			else
			{
				if ( !amo.iPath_ve[path_id].Tile_list.front().subject_ori )
					ori_check = true;
			}
			if ( ori_check )
			{
			/*	if ( amo.iPath_ve[path_id].Tile_list.front().pos_iPath.second - amo.iPath_ve[path_id].Tile_list.front().pos_iPath.first+1 >= 300 )
				{
					if ( ctgend-ctgstart+1 >= 300)
						rule = true;
				}  */
				rule = true;
			}
			logf<<"rule data: "<<rule<<" "<<ori_check<<" "<<amo.iPath_ve[path_id].Tile_list.size()<<" "
				<<amo.iPath_ve[path_id].Tile_list.front().pos_iPath.second - amo.iPath_ve[path_id].Tile_list.front().pos_iPath.first+1<<" "
				<<ctgend-ctgstart+1<<endl;
			if ( rule )
			{
				if ( in_or_out == 1 ) //in
				{
					qry_seg_in_link.insert( make_pair( sid, make_pair( path_id, 1 ) ) );
					amo.iPath_ve[path_id].seq.insert( 0, addseq );
					Tile tile;
					tile.ctg = qry_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgstart, ctgend );
					tile.subject_ori = false;
					tile.match = false;
					int frontpos = amo.iPath_ve[path_id].Tile_list.begin()->pos_iPath.first;
					tile.pos_iPath = make_pair( frontpos-(ctgend-ctgstart+1), frontpos-1 );
					amo.iPath_ve[path_id].Tile_list.push_front( tile );
					added_qry_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_query.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add qry_seg_in_link "<<sid<<" "<<path_id<<" 1"<<endl;
				} else   // out
				{
					qry_seg_out_link.insert( make_pair( sid, make_pair( path_id, 1 ) ) );
					string tra_seq = getsuppl_str( addseq );
					amo.iPath_ve[path_id].seq.insert( 0, tra_seq );
					Tile tile;
					tile.ctg = qry_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgend, ctgstart );
					tile.subject_ori = false;
					tile.match = false;
					int frontpos = amo.iPath_ve[path_id].Tile_list.begin()->pos_iPath.first;
					tile.pos_iPath = make_pair( frontpos-(ctgend-ctgstart+1), frontpos-1 );
					amo.iPath_ve[path_id].Tile_list.push_front( tile );
					added_qry_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_query.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add qry_seg_out_link "<<sid<<" "<<path_id<<" 1"<<endl;
				}
			}
		} else   // back
		{
			bool rule = false;
			bool ori_check = false;
			if ( amo.iPath_ve[path_id].Tile_list.size() <= 2 )
				ori_check = true;
			else
			{
				if ( !amo.iPath_ve[path_id].Tile_list.back().subject_ori )
					ori_check = true;
			}
			if ( ori_check )
			{
			/*	if ( amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second - amo.iPath_ve[path_id].Tile_list.back().pos_iPath.first+1 >= 300 )
				{
					if ( ctgend-ctgstart+1 >= 300)
						rule = true;
				}  */
				rule = true;
			}
			if ( rule )
			{
				if ( in_or_out == 1 )
				{
					qry_seg_in_link.insert( make_pair( sid, make_pair( path_id, 0 ) ) );
					string tra_seq = getsuppl_str( addseq );
					amo.iPath_ve[path_id].seq.insert( amo.iPath_ve[path_id].seq.size(), tra_seq );
					Tile tile;
					tile.ctg = qry_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgend, ctgstart );
					tile.subject_ori = false;
					tile.match = false;
					int backpos = amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second;
					tile.pos_iPath = make_pair( backpos+1, backpos+(ctgend-ctgstart+1) );
					amo.iPath_ve[path_id].Tile_list.push_back( tile );
					added_qry_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_query.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add qry_seg_in_link "<<sid<<" "<<path_id<<" 0"<<endl;
				} else
				{
					qry_seg_out_link.insert( make_pair( sid, make_pair( path_id, 0 ) ) );
					amo.iPath_ve[path_id].seq.insert( amo.iPath_ve[path_id].seq.size(), addseq );
					Tile tile;
					tile.ctg = qry_seg_ve[sid].ctg;
					tile.pos_ctg = make_pair( ctgstart, ctgend );
					tile.subject_ori = false;
					tile.match = false;
					int backpos = amo.iPath_ve[path_id].Tile_list.back().pos_iPath.second;
					tile.pos_iPath = make_pair( backpos+1, backpos+(ctgend-ctgstart+1) );
					amo.iPath_ve[path_id].Tile_list.push_back( tile );
					added_qry_seg.insert( sid );
					logf<<"addpath "<<path_id<<" "<<tile.subject_ori<<" "<<ass_bank.ass_query.Contigs[tile.ctg].name<<" "<<back_or_front<<" "<<in_or_out<<endl;
					logf<<"add qry_seg_out_link "<<sid<<" "<<path_id<<" 0"<<endl;
				}
			}
		}
	}

	// linking paths
	// get overlap
	vector< Path_Overlap > pathov;
	map< size_t, size_t > path_back_link;
	map< size_t, size_t > path_front_link;
	for ( map< Seg_id, pair< size_t, int > >::iterator ite = ref_seg_out_link.begin(); ite != ref_seg_out_link.end(); ++ite )
	{
		if ( ref_seg_in_link.find( ite->first ) != ref_seg_in_link.end() )
		{
			logf<<"overlap_sid "<<ite->first<<endl;
			Path_Overlap pob;
			pob.pathleft = ite->second.first;
			pob.linkside_pathleft = ite->second.second;
			pob.pathright = ref_seg_in_link[ite->first].first;
			pob.linkside_pathright = ref_seg_in_link[ite->first].second;
			pob.ovlen = ref_seg_ve[ite->first].end-ref_seg_ve[ite->first].start+1;
			pathov.push_back( pob );
			size_t plid = pathov.size()-1;
			if ( pob.linkside_pathleft == 1 )
			{
				path_front_link.insert( make_pair( pob.pathleft, plid ) );
				logf<<"path_front_link insert P"<<pob.pathleft<<endl;
			} else
			{
				path_back_link.insert( make_pair( pob.pathleft, plid ) );
				logf<<"path_back_link insert P"<<pob.pathleft<<endl;
			}
			if ( pob.linkside_pathright == 1 )
			{
				path_front_link.insert( make_pair( pob.pathright, plid ) );
				logf<<"path_front_link insert P"<<pob.pathright<<endl;
			} else
			{
				path_back_link.insert( make_pair( pob.pathright, plid ) );
				logf<<"path_back_link insert P"<<pob.pathright<<endl;
			}
			logf<<"path overlap link(ref): P"<<pob.pathleft<<" "<<pob.linkside_pathleft<<" P"<<pob.pathright<<" "<<pob.linkside_pathright<<endl; 
		}
	}
	for ( map< Seg_id, pair< size_t, int > >::iterator ite = qry_seg_out_link.begin(); ite != qry_seg_out_link.end(); ++ite )
	{
		if ( qry_seg_in_link.find( ite->first ) != qry_seg_in_link.end() )
		{
			logf<<"overlap_sid "<<ite->first<<endl;
			Path_Overlap pob;
			pob.pathleft = ite->second.first;
			pob.linkside_pathleft = ite->second.second;
			pob.pathright = qry_seg_in_link[ite->first].first;
			pob.linkside_pathright = qry_seg_in_link[ite->first].second;
			pob.ovlen = qry_seg_ve[ite->first].end - qry_seg_ve[ite->first].start+1;
			pathov.push_back( pob );
			size_t plid = pathov.size()-1;
			if ( pob.linkside_pathleft == 1 )
			{
				path_front_link.insert( make_pair( pob.pathleft, plid ) );
				logf<<"path_front_link insert P"<<pob.pathleft<<endl;
			} else
			{
				path_back_link.insert( make_pair( pob.pathleft, plid ) );
				logf<<"path_back_link insert P"<<pob.pathleft<<endl;
			}
			if ( pob.linkside_pathright == 1 )
			{
				logf<<"path_front_link insert P"<<pob.pathright<<endl;
				path_front_link.insert( make_pair( pob.pathright, plid ) );
			} else
			{
				path_back_link.insert( make_pair( pob.pathright, plid ) );
				logf<<"path_back_link insert P"<<pob.pathright<<endl;
			}
			logf<<"path overlap link(qry): P"<<pob.pathleft<<" "<<pob.linkside_pathleft<<" P"<<pob.pathright<<" "<<pob.linkside_pathright<<endl; 
		}
	}
	set< size_t > innerpath;
	for ( map< size_t, size_t >::iterator ite = path_back_link.begin(); ite != path_back_link.end(); ++ite )
	{
		if ( path_front_link.find( ite->first ) != path_front_link.end() )
		{
			logf<<"Inner P"<<ite->first<<endl;
			innerpath.insert( ite->first );
		}
	}
	set< size_t > usedpath;
	for ( map< size_t, size_t >::iterator ite = path_back_link.begin(); ite != path_back_link.end(); ++ite )
	{
		if ( usedpath.find( ite->first ) != usedpath.end() )
			continue;
		if ( innerpath.find( ite->first ) != innerpath.end() )
			continue;
		set< size_t > mergedpath;
		iPath ip;
		ip.seq = amo.iPath_ve[ite->first].seq;
		ip.Tile_list = amo.iPath_ve[ite->first].Tile_list;
		mergedpath.insert( ite->first );
		size_t lastpath = ite->first;
		int front_or_back = 0; //back
		size_t ov = ite->second;
		logf<<"pathlink begin path"<<ite->first<<" back"<<endl;
		bool goon = false;
		do {
			goon = false;
			size_t path_other;
			int front_or_back_other;
			getotherpath( pathov[ov], lastpath, path_other, front_or_back_other );
			logf<<"getotherpath "<<path_other<<" "<<front_or_back_other<<endl;
			if ( usedpath.find( path_other ) != usedpath.end() )
			{
				logf<<"path used"<<endl;
				break;
			}
			if ( front_or_back_other == 1 )
			{
				usedpath.insert( path_other );
				mergedpath.insert( path_other );
				int tl = amo.iPath_ve[path_other].Tile_list.front().pos_iPath.second-amo.iPath_ve[path_other].Tile_list.front().pos_iPath.first+1;
				if ( tl != pathov[ov].ovlen )
				{
					cout<<"error ovlen "<<amo.iPath_ve[path_other].Tile_list.front().pos_iPath.first<< ","
						<<amo.iPath_ve[path_other].Tile_list.front().pos_iPath.second<<","<<pathov[ov].ovlen<<endl;
					exit(1);
				}
			/*	if ( ip.Tile_list.back().ctg != amo.iPath_ve[path_other].Tile_list.front().ctg )
				{
					cout<<"error overlap ctg "<<ip.Tile_list.back().ctg<<", "<<amo.iPath_ve[path_other].Tile_list.front().ctg<<endl; exit(1);
				}*/
				
				int endlen = ip.Tile_list.back().pos_iPath.second;
				list< Tile >::iterator ti = amo.iPath_ve[path_other].Tile_list.begin();
				
				++ti;
				int ini_begin = ti->pos_iPath.first;
				for ( ; ti != amo.iPath_ve[path_other].Tile_list.end(); ++ti )
				{
					Tile tile;
					tile.ctg = ti->ctg;
					tile.subject_ori = ti->subject_ori;
					tile.pos_ctg = ti->pos_ctg;
					int rel_pos_1 = ti->pos_iPath.first - ini_begin + 1;
					tile.pos_iPath.first = endlen + rel_pos_1;
					int tlen = ti->pos_iPath.second-ti->pos_iPath.first+1;
					tile.pos_iPath.second = tile.pos_iPath.first + tlen -1;
					tile.match = ti->match;
					if ( ti->match )
					{
						tile.coo = ti->coo;
					}
					ip.Tile_list.push_back( tile );
				}
				string addseq = amo.iPath_ve[path_other].seq.substr( pathov[ov].ovlen );
				ip.seq.insert( ip.seq.size(), addseq );

				logf<<"path added!"<<endl;
				lastpath = path_other;
				front_or_back = 0;
				if ( path_back_link.find( lastpath ) != path_back_link.end() )
				{
					ov = path_back_link[lastpath];
					logf<<"goon"<<endl;
					goon = true;
				}
			} else
			{
				usedpath.insert( path_other );
				mergedpath.insert( path_other );
				int tl = amo.iPath_ve[path_other].Tile_list.back().pos_iPath.second-amo.iPath_ve[path_other].Tile_list.back().pos_iPath.first+1;
				if ( tl != pathov[ov].ovlen )
				{
					cout<<"error ovlen "<<amo.iPath_ve[path_other].Tile_list.back().pos_iPath.first<< ","
						<<amo.iPath_ve[path_other].Tile_list.back().pos_iPath.second<<","<<pathov[ov].ovlen<<endl;
					exit(1);
				}
			/*	if ( ip.Tile_list.back().ctg != amo.iPath_ve[path_other].Tile_list.back().ctg )
				{
					cout<<"error overlap ctg "<<ip.Tile_list.back().ctg<<", "<<amo.iPath_ve[path_other].Tile_list.back().ctg<<endl; exit(1);
				} */

				int endlen = ip.Tile_list.back().pos_iPath.second;
				list< Tile >::reverse_iterator ti = amo.iPath_ve[path_other].Tile_list.rbegin();
				++ti;
				int ini_end = ti->pos_iPath.second;
				for ( ; ti != amo.iPath_ve[path_other].Tile_list.rend(); ++ti )
				{
					Tile tile;
					tile.ctg = ti->ctg;
					tile.subject_ori = ti->subject_ori;
					tile.pos_ctg.first = ti->pos_ctg.second;
					tile.pos_ctg.second = ti->pos_ctg.first;
					int rel_pos_1 = ini_end-ti->pos_iPath.second+1;
					tile.pos_iPath.first = endlen + rel_pos_1;
					int tlen = ti->pos_iPath.second-ti->pos_iPath.first+1;
					tile.pos_iPath.second = tile.pos_iPath.first + tlen -1;
					tile.match = ti->match;
					if ( ti->match )
					{
						tile.coo = ti->coo;
					}
					ip.Tile_list.push_back( tile );
				}

				string addseq = getsuppl_str( amo.iPath_ve[path_other].seq );
				addseq = addseq.substr( pathov[ov].ovlen );
				ip.seq.insert( ip.seq.size(), addseq );

				logf<<"path added!"<<endl;
				lastpath = path_other;
				front_or_back = 1;

				if ( path_front_link.find( lastpath ) != path_front_link.end() )
				{
					ov = path_front_link[lastpath];
					logf<<"goon"<<endl;
					goon = true;
				}
			} 

		} while ( goon );

		amo.iPath_ve.push_back( ip );
		for ( set< size_t >::iterator mi = mergedpath.begin(); mi != mergedpath.end(); ++mi )
		{
			logf<<"erase merged path P"<<*mi<<endl;
			amo.iPath_ve[*mi].seq.clear();
			amo.iPath_ve[*mi].Tile_list.clear();
		}
		
	}
	for ( map< size_t, size_t >::iterator ite = path_front_link.begin(); ite != path_front_link.end(); ++ite )
	{
		if ( usedpath.find( ite->first ) != usedpath.end() )
			continue;
		if ( innerpath.find( ite->first ) != innerpath.end() )
			continue;
		set< size_t > mergedpath;
		iPath ip;
		ip.seq = getsuppl_str( amo.iPath_ve[ite->first].seq );
		int endlen_0 = 0;
		for ( list< Tile >::reverse_iterator ti = amo.iPath_ve[ite->first].Tile_list.rbegin(); ti != amo.iPath_ve[ite->first].Tile_list.rend(); ++ti )
		{
			Tile tile;
			tile.ctg = ti->ctg;
			tile.subject_ori = ti->subject_ori;
			tile.pos_ctg.first = ti->pos_ctg.second;
			tile.pos_ctg.second = ti->pos_ctg.first;
			int rel_pos_1 = amo.iPath_ve[ite->first].Tile_list.back().pos_iPath.second-ti->pos_iPath.second+1;
			tile.pos_iPath.first = endlen_0 + rel_pos_1;
			int tlen = ti->pos_iPath.second-ti->pos_iPath.first+1;
			tile.pos_iPath.second = tile.pos_iPath.first + tlen -1;
			tile.match = ti->match;
			if ( ti->match )
			{
				tile.coo = ti->coo;
			}
			ip.Tile_list.push_back( tile );
		}
		mergedpath.insert( ite->first );
		size_t lastpath = ite->first;
		int front_or_back = 1; //front
		size_t ov = ite->second;
		logf<<"pathlink begin path"<<ite->first<<" front"<<endl;
		bool goon = false;
		do {
			goon = false;
			size_t path_other;
			int front_or_back_other;
			getotherpath( pathov[ov], lastpath, path_other, front_or_back_other );
			logf<<"getotherpath "<<path_other<<" "<<front_or_back_other<<endl;
			if ( usedpath.find( path_other ) != usedpath.end() )
			{
				logf<<"path used"<<endl;
				break;
			}
			if ( front_or_back_other == 1 )
			{
				usedpath.insert( path_other );
				mergedpath.insert( path_other );
				int tl = amo.iPath_ve[path_other].Tile_list.front().pos_iPath.second-amo.iPath_ve[path_other].Tile_list.front().pos_iPath.first+1;
				if ( tl != pathov[ov].ovlen )
				{
					cout<<"error ovlen "<<amo.iPath_ve[path_other].Tile_list.front().pos_iPath.first<< ","
						<<amo.iPath_ve[path_other].Tile_list.front().pos_iPath.second<<","<<pathov[ov].ovlen<<endl;
					exit(1);
				}
			/*	if ( ip.Tile_list.back().ctg != amo.iPath_ve[path_other].Tile_list.front().ctg )
				{
					cout<<"error overlap ctg "<<ip.Tile_list.back().ctg<<", "<<amo.iPath_ve[path_other].Tile_list.front().ctg<<endl; exit(1);
				}*/
				
				int endlen = ip.Tile_list.back().pos_iPath.second;
				list< Tile >::iterator ti = amo.iPath_ve[path_other].Tile_list.begin();
				++ti;
				int ini_begin = ti->pos_iPath.first;
				for ( ; ti != amo.iPath_ve[path_other].Tile_list.end(); ++ti )
				{
					Tile tile;
					tile.ctg = ti->ctg;
					tile.subject_ori = ti->subject_ori;
					tile.pos_ctg = ti->pos_ctg;
					int rel_pos_1 = ti->pos_iPath.first - ini_begin + 1;
					tile.pos_iPath.first = endlen + rel_pos_1;
					int tlen = ti->pos_iPath.second-ti->pos_iPath.first+1;
					tile.pos_iPath.second = tile.pos_iPath.first + tlen -1;
					tile.match = ti->match;
					if ( ti->match )
					{
						tile.coo = ti->coo;
					}
					ip.Tile_list.push_back( tile );
				}

				string addseq = amo.iPath_ve[path_other].seq.substr( pathov[ov].ovlen );
				ip.seq.insert( ip.seq.size(), addseq );

				logf<<"path added!"<<endl;
				lastpath = path_other;
				front_or_back = 0;
				if ( path_back_link.find( lastpath ) != path_back_link.end() )
				{
					logf<<"goon"<<endl;
					ov = path_back_link[lastpath];
					goon = true;
				}
			} else
			{
				usedpath.insert( path_other );
				mergedpath.insert( path_other );
				int tl = amo.iPath_ve[path_other].Tile_list.back().pos_iPath.second-amo.iPath_ve[path_other].Tile_list.back().pos_iPath.first+1;
				if ( tl != pathov[ov].ovlen )
				{
					cout<<"error ovlen "<<amo.iPath_ve[path_other].Tile_list.back().pos_iPath.first<< ","
						<<amo.iPath_ve[path_other].Tile_list.back().pos_iPath.second<<","<<pathov[ov].ovlen<<endl;
					exit(1);
				}
			/*	if ( ip.Tile_list.back().ctg != amo.iPath_ve[path_other].Tile_list.back().ctg )
				{
					cout<<"error overlap ctg "<<ip.Tile_list.back().ctg<<", "<<amo.iPath_ve[path_other].Tile_list.back().ctg<<endl; exit(1);
				} */

				int endlen = ip.Tile_list.back().pos_iPath.second;
				list< Tile >::reverse_iterator ti = amo.iPath_ve[path_other].Tile_list.rbegin();
				++ti;
				int ini_end = ti->pos_iPath.second;
				for ( ; ti != amo.iPath_ve[path_other].Tile_list.rend(); ++ti )
				{
					Tile tile;
					tile.ctg = ti->ctg;
					tile.subject_ori = ti->subject_ori;
					tile.pos_ctg.first = ti->pos_ctg.second;
					tile.pos_ctg.second = ti->pos_ctg.first;
					int rel_pos_1 = ini_end-ti->pos_iPath.second+1;
					tile.pos_iPath.first = endlen + rel_pos_1;
					int tlen = ti->pos_iPath.second-ti->pos_iPath.first+1;
					tile.pos_iPath.second = tile.pos_iPath.first + tlen -1;
					tile.match = ti->match;
					if ( ti->match )
					{
						tile.coo = ti->coo;
					}
					ip.Tile_list.push_back( tile );
				}
				string addseq = getsuppl_str( amo.iPath_ve[path_other].seq );
				addseq = addseq.substr( pathov[ov].ovlen );
				ip.seq.insert( ip.seq.size(), addseq );

				logf<<"path added!"<<endl;
				lastpath = path_other;
				front_or_back = 1;

				if ( path_front_link.find( lastpath ) != path_front_link.end() )
				{
					logf<<"goon"<<endl;
					ov = path_front_link[lastpath];
					goon = true;
				}
			} 

		} while ( goon );

		amo.iPath_ve.push_back( ip );
		for ( set< size_t >::iterator mi = mergedpath.begin(); mi != mergedpath.end(); ++mi )
		{
			logf<<"erase merged path P"<<*mi<<endl;
			amo.iPath_ve[*mi].seq.clear();
			amo.iPath_ve[*mi].Tile_list.clear();
		}
		
	}
	// debug
/*	for ( set< size_t >::iterator ite = innerpath.begin(); ite != innerpath.end(); ++ite )
	{
		if ( usedpath.find( *ite ) == usedpath.end() )
		{
			cout<<"error unused innerpath "<<*ite<<endl; exit(1);
		}
	}*/
	

	// add unmaped ctg
	for ( size_t i = 0; i < unmap_refctg_ve.size(); ++i )
	{
		iPath ip;
		ip.seq = ass_bank.ass_subject.Contigs[unmap_refctg_ve[i]].seq;
		Tile tile;
		tile.ctg = unmap_refctg_ve[i];
		tile.pos_ctg = make_pair( 1, ass_bank.ass_subject.Contigs[unmap_refctg_ve[i]].length );
		tile.pos_iPath = tile.pos_ctg;
		tile.subject_ori = true;
		tile.match = false;
		ip.Tile_list.push_back( tile );
		amo.iPath_ve.push_back( ip );
		size_t path_id = amo.iPath_ve.size()-1;
		logf<<"add unmap ctg ref "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<endl;
	}
	for ( size_t i = 0; i < unmap_qryctg_ve.size(); ++i )
	{
		iPath ip;
		ip.seq = ass_bank.ass_query.Contigs[unmap_qryctg_ve[i]].seq;
		Tile tile;
		tile.ctg = unmap_qryctg_ve[i];
		tile.pos_ctg = make_pair( 1, ass_bank.ass_query.Contigs[unmap_qryctg_ve[i]].length );
		tile.pos_iPath = tile.pos_ctg;
		tile.subject_ori = false;
		tile.match = false;
		ip.Tile_list.push_back( tile );
		amo.iPath_ve.push_back( ip );
		logf<<"add unmap ctg qry "<<ass_bank.ass_query.Contigs[tile.ctg].name<<endl;
	}

	// add unlinked seg.
	for ( size_t i = 0; i < ref_seg_ve.size(); ++i )
	{
		if ( added_ref_seg.find( i ) == added_ref_seg.end() )
		{
			int ctgstart = ref_seg_ve[i].start;
			int ctgend = ref_seg_ve[i].end;
			if ( ctgend-ctgstart+1 >= 200 )
			{
				string addseq = ass_bank.ass_subject.Contigs[ref_seg_ve[i].ctg].seq.substr( ctgstart-1, ctgend-ctgstart+1 );
				iPath ip;
				ip.seq = addseq;
				Tile tile;
				tile.ctg = ref_seg_ve[i].ctg;
				tile.pos_ctg = make_pair( ctgstart, ctgend );
				tile.pos_iPath = make_pair( 1, (ctgend-ctgstart+1) );
				tile.subject_ori = true;
				tile.match = false;
				ip.Tile_list.push_back( tile );
				amo.iPath_ve.push_back( ip );
				logf<<"add unmap seg ref "<<ass_bank.ass_subject.Contigs[tile.ctg].name<<" "<<tile.pos_ctg.first<<" "<<tile.pos_ctg.second<<endl;
			}
		}
	}
	for ( size_t i = 0; i < qry_seg_ve.size(); ++i )
	{
		if ( added_qry_seg.find( i ) == added_qry_seg.end() )
		{
			
			int ctgstart = qry_seg_ve[i].start;
			int ctgend = qry_seg_ve[i].end;
			if ( ctgend-ctgstart+1 >= 200 )
			{
				string addseq = ass_bank.ass_query.Contigs[qry_seg_ve[i].ctg].seq.substr( ctgstart-1, ctgend-ctgstart+1 );
				iPath ip;
				ip.seq = addseq;
				Tile tile;
				tile.ctg = qry_seg_ve[i].ctg;
				tile.pos_ctg = make_pair( ctgstart, ctgend );
				tile.pos_iPath = make_pair( 1, ctgend-ctgstart+1 );
				tile.subject_ori = false;
				tile.match = false;
				ip.Tile_list.push_back( tile );
				amo.iPath_ve.push_back( ip );
				logf<<"add unmap seg qry "<<ass_bank.ass_query.Contigs[tile.ctg].name<<" "<<tile.pos_ctg.first<<" "<<tile.pos_ctg.second<<endl;
			}
		}
	}

	// erase contained path
	for ( size_t i = 0; i < amo.iPath_ve.size(); ++i )
	{
		bool noc = false;
		for ( list< Tile >::iterator ci = amo.iPath_ve[i].Tile_list.begin(); ci != amo.iPath_ve[i].Tile_list.end(); ++ci )
		{
			if ( !ci->match )
			{
				noc = true;
				break;
			}
			if ( contained_coo.find( ci->coo ) == contained_coo.end() )
			{
				noc = true;
				break;
			}
		}
		if ( !noc )
		{
			logf<<"erase contained path P"<<i<<endl;
			amo.iPath_ve[i].seq.clear();
			amo.iPath_ve[i].Tile_list.clear();
		}
	}

	// debug
	for ( size_t i = 0; i < amo.iPath_ve.size(); ++i )
	{
		if ( amo.iPath_ve[i].seq.empty() )
			continue;
		int len = amo.iPath_ve[i].Tile_list.back().pos_iPath.second - amo.iPath_ve[i].Tile_list.front().pos_iPath.first+1;
		if ( len != (int)amo.iPath_ve[i].seq.size() )
		{
			cout<<"error debug "<<i<<" "<<len<<" "<<amo.iPath_ve[i].seq.size()<<endl; 
			list< Tile >::iterator ite = amo.iPath_ve[i].Tile_list.begin();
			for ( ; ite != amo.iPath_ve[i].Tile_list.end(); ++ite )
			{
				cout<<ite->subject_ori;
				if ( ite->subject_ori )
					cout<<","<<ass_bank.ass_subject.Contigs[ite->ctg].name;
				else
					cout<<","<<ass_bank.ass_query.Contigs[ite->ctg].name;
				cout<<","<<ite->pos_ctg.first<<","<<ite->pos_ctg.second<<","<<ite->pos_iPath.first<<","<<ite->pos_iPath.second<<endl;
			}
			exit(1);
		}
	}

}

void getotherpath( Path_Overlap &pob, size_t path_in, size_t& path_other, int& front_or_back_other )
{
	if ( pob.pathleft == path_in )
	{
		path_other = pob.pathright;
		front_or_back_other = pob.linkside_pathright;
	} else if ( pob.pathright == path_in )
	{
		path_other = pob.pathleft;
		front_or_back_other = pob.linkside_pathleft;
	} else
	{
		cout<<"error no path "<<path_in<< " in pob "<<endl; exit(1);
	}

}

bool checkbreak_validate( Contig &ctg, int cutpoint )
{
	if ( ctg.suspicious_range.empty() )
		return false;

	int front = max( 1, cutpoint - 200 );
	int end = min( ctg.length, cutpoint + 200 );

	for ( size_t j = 0; j < ctg.suspicious_range.size(); ++j )
	{
					
		if ( pos_overlap( front-1, end, ctg.suspicious_range[j].first-1, ctg.suspicious_range[j].second ) )
		{
			
			return true;
			
		}
	}
	return false;
}

void getunmapseg( Ctg_id i, Contig& ctg, vector< Seg > &t_seg_ve, Ass_Mapping &amo, bool subject )
{
	
	if ( subject )
	{
		vector< pair<int, int > >::iterator ite = ctg.uni_mapping_range.begin();
		vector< bool >::iterator bkite = ctg.break_by_validate.begin();
	//	multimap< pair<int, int >, Coords_id >::iterator ite = ass_bank.ass_subject.Contigs[i].mapping.begin();
		pair<int, int > frontrg = *ite;
		Coords_id coo = ctg.mapping.lower_bound( *ite )->second;
		if ( frontrg.first > 50 )
		{
			Seg sg;
			sg.subject = true;
			sg.ctg = i;
			sg.start = 1;
			sg.end = frontrg.first-1;
			
			t_seg_ve.push_back( sg );
		
		}
		

		for ( ; ite != ctg.uni_mapping_range.end(); ++ite )
		{
			vector< pair<int, int > >::iterator secite = ite;
			++secite;
			if ( secite == ctg.uni_mapping_range.end() )
				break;
			frontrg = *ite;
			Coords_id frontcoo = ctg.mapping.lower_bound( *ite )->second;
			pair< int, int > nextrg = *secite;
			Coords_id nextcoo = ctg.mapping.lower_bound( *secite )->second;
			int start = frontrg.second + 1;
			int end = nextrg.first - 1;
			if ( end - start + 1 >= 50 )
			{
				bool um = false;
				if ( amo.in_avail_coo.find( frontcoo ) != amo.in_avail_coo.end() || amo.out_avail_coo.find( nextcoo ) != amo.out_avail_coo.end() )
				{
					
					um = true;
				}
				else if ( *bkite )
				{
					
					um = true;
				} else if ( ctg.uni_mapping_coo.find( frontrg ) == ctg.uni_mapping_coo.end() || ctg.uni_mapping_coo.find( nextrg ) == ctg.uni_mapping_coo.end() )
				{
					
					um = true;
				}
				bool tried_link = false;
				if ( end-start+1 < 400 )
					tried_link = true;
				if ( um )
				{
					Seg sg;
					sg.subject = true;
					sg.ctg = i;
					sg.start = start;
					sg.end = end;
					
					t_seg_ve.push_back( sg );
					
					
				}
			}
			++bkite;
		}

		frontrg = *ite;
		coo = ctg.mapping.lower_bound( *ite )->second;
		if ( ctg.length - frontrg.second >= 50 )
		{
			Seg sg;
			sg.subject = true;
			sg.ctg = i;
			sg.start = frontrg.second + 1;
			sg.end = ctg.length;
			
			t_seg_ve.push_back( sg );
			
			
			
		}

	} else
	{
		vector< pair<int, int > >::iterator ite = ctg.uni_mapping_range.begin();
		vector< bool >::iterator bkite = ctg.break_by_validate.begin();
		pair<int, int > frontrg = *ite;
		Coords_id coo = ctg.mapping.lower_bound( *ite )->second;
		bool forward = true;
		if ( amo.mcoords[coo].qryend() < amo.mcoords[coo].qrystart() )
			forward = false;
		if ( frontrg.first > 50 )
		{

			Seg sg;
			sg.subject = false;
			sg.ctg = i;
			sg.start = 1;
			sg.end = frontrg.first-1;
			t_seg_ve.push_back( sg );
			
			
		}

		for ( ; ite != ctg.uni_mapping_range.end(); ++ite )
		{
			vector< pair<int, int > >::iterator secite = ite;
			++secite;
			if ( secite == ctg.uni_mapping_range.end() )
				break;
			frontrg = *ite;
			Coords_id frontcoo = ctg.mapping.lower_bound( *ite )->second;
			pair< int, int > nextrg = *secite;
			Coords_id nextcoo = ctg.mapping.lower_bound( *secite )->second;

			bool frontforward = true;
			if ( amo.mcoords[frontcoo].qryend() < amo.mcoords[frontcoo].qrystart() )
				frontforward = false;
			bool nextforward = true;
			if ( amo.mcoords[nextcoo].qryend() < amo.mcoords[nextcoo].qrystart() )
				nextforward = false;

			int start = frontrg.second + 1;
			int end = nextrg.first - 1;
			if ( end - start + 1 >= 50 )
			{
				bool um = false;
				if ( *bkite )
				{
					
					um = true;
				} else if ( ctg.uni_mapping_coo.find( frontrg ) == ctg.uni_mapping_coo.end() || ctg.uni_mapping_coo.find( nextrg ) == ctg.uni_mapping_coo.end() )
				{
					
					um = true;
				} else
				{
					if ( frontforward )
					{
						if ( amo.in_avail_coo.find( frontcoo ) != amo.in_avail_coo.end() )
						{
							um = true;
						}
					} else
					{
						if ( amo.out_avail_coo.find( frontcoo ) != amo.out_avail_coo.end() )
						{
							um = true;
						}
					}
					if ( nextforward )
					{
						if ( amo.out_avail_coo.find( nextcoo ) != amo.out_avail_coo.end() )
						{
							um = true;
						}
					} else
					{
						if ( amo.in_avail_coo.find( nextcoo ) != amo.in_avail_coo.end() )
							um = true;
					}
				}
				bool tried_link = false;
				if ( end-start+1 < 400 )
					tried_link = true;
				if ( um )
				{
					Seg sg;
					sg.subject = true;
					sg.ctg = i;
					sg.start = start;
					sg.end = end;
					
					t_seg_ve.push_back( sg );
					
					
				}
			}
			++bkite;
		}

		frontrg = *ite;
		coo = ctg.mapping.lower_bound( *ite )->second;
		if ( ctg.length - frontrg.second >= 50 )
		{
			Seg sg;
			sg.subject = true;
			sg.ctg = i;
			sg.start = frontrg.second + 1;
			sg.end = ctg.length;
			
			t_seg_ve.push_back( sg );
			
			
			
		}

	}

	
}

void crosssmallrep( vector< Seg > &t_seg_ve, int length, set< pair<int, int > > &merged_unmaprange )
{
	int ttseglen = 0;
	for ( size_t i = 0; i < t_seg_ve.size(); ++i )
	{
		ttseglen += t_seg_ve[i].end-t_seg_ve[i].start+1;
	}
	set< size_t > adh;
	int leftaddedl = 0;
	for ( size_t i = 0; i < t_seg_ve.size(); ++i )
	{
		if ( i+1 == t_seg_ve.size() )
			break;
		leftaddedl += t_seg_ve[i].end - t_seg_ve[i].start+1;
		int rightl = ttseglen-leftaddedl;
		int midlength = t_seg_ve[i+1].start-t_seg_ve[i].end+1;
		if ( midlength < 500 && ( leftaddedl > midlength * 2 ) && ( rightl > midlength * 2 ) && ( ttseglen > midlength * 10 ) )
		{
			adh.insert( i );
		}
	}
	size_t i = 0;
	while ( i < t_seg_ve.size() )
	{
		int l = t_seg_ve[i].start;
		int r = t_seg_ve[i].end;
		while ( adh.find( i ) != adh.end() )
		{
			++i;
			r = t_seg_ve[i].end;
			if ( i == t_seg_ve.size() )
				break;
			
		}
		merged_unmaprange.insert( make_pair( l, r ) );
		++i;
	}
}

void markcontainedunimapping( set< size_t > &uncontained, vector< pair<int, int > > &unimaprange, set< pair<int, int > > &merged_unmaprange )
{

	for ( size_t i = 0; i < unimaprange.size(); ++i )
	{
		bool ct = false;
		for ( set< pair<int, int > >::iterator ite = merged_unmaprange.begin(); ite != merged_unmaprange.end(); ++ite )
		{
			if ( unimaprange[i].first >= ite->first && unimaprange[i].second <= ite->second )
			{
				ct = true;
				break;
			}
		}
		if ( !ct )
			uncontained.insert( i );
	}
}

void getoverlap( int pa_1, int pa_2, int pb_1, int pb_2, int& ov_1, int& ov_2 )  
{
	if ( pa_2 < pb_1 || pb_2 < pa_1 )
		return;
	ov_1 = max( pa_1, pb_1 );
	ov_2 = min( pa_2, pb_2 );
}

void anaunmerged( Ass_Mapping &amo, Assembly_Bank &ass_bank )
{
	// get unmerged range;
	map< Ctg_id, vector< pair<int, int > > > ref_unmerged;
	map< Ctg_id, vector< pair<int, int > > > qry_unmerged;

	map< Ctg_id, vector< pair<int,int > > > ref_merged_rg;
	map< Ctg_id, vector< pair<int,int > > > qry_merged_rg;

	for ( size_t i = 0; i < amo.iPath_ve.size(); ++i )
	{
		for ( list< Tile >::iterator ite = amo.iPath_ve[i].Tile_list.begin(); ite != amo.iPath_ve[i].Tile_list.end(); ++ite )
		{
			if ( ite->match )
			{
				Ctg_id refctg = ass_bank.ass_subject.ctg_name_map[amo.mcoords[ite->coo].refname()];
				ref_merged_rg[refctg].push_back( make_pair( amo.mcoords[ite->coo].refstart(), amo.mcoords[ite->coo].refend() ) );
				Ctg_id qryctg = ass_bank.ass_query.ctg_name_map[amo.mcoords[ite->coo].qryname()];
				int qrystart = min( amo.mcoords[ite->coo].qrystart(), amo.mcoords[ite->coo].qryend() );
				int qryend = max( amo.mcoords[ite->coo].qrystart(), amo.mcoords[ite->coo].qryend() );
				qry_merged_rg[qryctg].push_back( make_pair( qrystart, qryend ) );
			} else
			{
				if ( ite->subject_ori )
				{
					int start = min( ite->pos_ctg.first, ite->pos_ctg.second );
					int end = max( ite->pos_ctg.first, ite->pos_ctg.second );
					ref_merged_rg[ite->ctg].push_back( make_pair( start, end ) );

				} else
				{
					int start = min( ite->pos_ctg.first, ite->pos_ctg.second );
					int end = max( ite->pos_ctg.first, ite->pos_ctg.second );
					qry_merged_rg[ite->ctg].push_back( make_pair( start, end ) );
				}
			}
		}
	}

	for ( map< Ctg_id, vector< pair<int,int > > >::iterator ite = ref_merged_rg.begin(); ite != ref_merged_rg.end(); ++ite )
	{
		mergerange( ite->second );
	}
	for ( map< Ctg_id, vector< pair<int,int > > >::iterator ite = qry_merged_rg.begin(); ite != qry_merged_rg.end(); ++ite ) 
	{
		mergerange( ite->second );
	}

	for ( size_t i = 0; i < ass_bank.ass_subject.Contigs.size(); ++i )
	{
		vector< pair<int, int > >  unmerged;
		if ( ref_merged_rg.find( i ) != ref_merged_rg.end() )
		{
			getminusrange_wholectg( ref_merged_rg[i], ass_bank.ass_subject.Contigs[i].length, unmerged );
		} else
		{
			unmerged.push_back( make_pair( 1, ass_bank.ass_subject.Contigs[i].length ) );
		}
		if ( !unmerged.empty() )
		{
			ref_unmerged.insert( make_pair( i, unmerged ) );
		}
	}
	for ( size_t i = 0; i < ass_bank.ass_query.Contigs.size(); ++i )
	{
		vector< pair<int, int > >  unmerged;
		if ( qry_merged_rg.find( i ) != qry_merged_rg.end() )
		{
			getminusrange_wholectg( qry_merged_rg[i], ass_bank.ass_query.Contigs[i].length, unmerged );
		} else
		{
			unmerged.push_back( make_pair( 1, ass_bank.ass_query.Contigs[i].length ) );
		}
		if ( !unmerged.empty() )
		{
			qry_unmerged.insert( make_pair( i, unmerged ) );
		}
	}

	// unmatched range
	map< Ctg_id, vector< pair<int, int > > > ref_unmatched;
	map< Ctg_id, vector< pair<int, int > > > qry_unmatched;

	map< Ctg_id, vector< pair<int,int > > > ref_matched_rg;
	map< Ctg_id, vector< pair<int,int > > > qry_matched_rg;

	for ( size_t i = 0; i < amo.mcoords.size(); ++i )
	{
		Ctg_id refctg = ass_bank.ass_subject.ctg_name_map[amo.mcoords[i].refname()];
		ref_matched_rg[refctg].push_back( make_pair( amo.mcoords[i].refstart(), amo.mcoords[i].refend() ) );
		Ctg_id qryctg = ass_bank.ass_query.ctg_name_map[amo.mcoords[i].qryname()];
		int start = min( amo.mcoords[i].qrystart(), amo.mcoords[i].qryend() );
		int end = max( amo.mcoords[i].qrystart(), amo.mcoords[i].qryend() );
		qry_matched_rg[qryctg].push_back( make_pair( start, end ) );
	}

	for ( map< Ctg_id, vector< pair<int,int > > >::iterator ite = ref_matched_rg.begin(); ite != ref_matched_rg.end(); ++ite )
	{
		mergerange( ite->second );
	}
	for ( map< Ctg_id, vector< pair<int,int > > >::iterator ite = qry_matched_rg.begin(); ite != qry_matched_rg.end(); ++ite ) 
	{
		mergerange( ite->second );
	}
	for ( size_t i = 0; i < ass_bank.ass_subject.Contigs.size(); ++i )
	{
		vector< pair<int, int > >  unmatched;
		if ( ref_matched_rg.find( i ) != ref_matched_rg.end() )
		{
			getminusrange_wholectg( ref_matched_rg[i], ass_bank.ass_subject.Contigs[i].length, unmatched );
		} else
		{
			unmatched.push_back( make_pair( 1, ass_bank.ass_subject.Contigs[i].length ) );
		}
		if ( !unmatched.empty() )
		{
			ref_unmatched.insert( make_pair( i, unmatched ) );
		}
	}
	for ( size_t i = 0; i < ass_bank.ass_query.Contigs.size(); ++i )
	{
		vector< pair<int, int > >  unmatched;
		if ( qry_matched_rg.find( i ) != qry_matched_rg.end() )
		{
			getminusrange_wholectg( qry_matched_rg[i], ass_bank.ass_query.Contigs[i].length, unmatched );
		} else
		{
			unmatched.push_back( make_pair( 1, ass_bank.ass_query.Contigs[i].length ) );
		}
		if ( !unmatched.empty() )
		{
			qry_unmatched.insert( make_pair( i, unmatched ) );
		}
	}

	// ana and output
	string outfile = "unmerged";
	ofstream outf( outfile.data() );
	for ( map< Ctg_id, vector< pair<int, int > > >::iterator ite = ref_unmerged.begin(); ite != ref_unmerged.end(); ++ite )
	{
		outf<<">ref_"<<ass_bank.ass_subject.Contigs[ite->first].name<<" "<<ass_bank.ass_subject.Contigs[ite->first].length<<endl;
		for ( vector< pair<int, int > >::iterator subi = ite->second.begin(); subi != ite->second.end(); ++subi )
		{
			outf<<subi->first<<","<<subi->second;
			vector< pair<int, int > > unmatched;
			if ( ref_unmatched.find( ite->first ) != ref_unmatched.end() )
			{
				for ( vector< pair<int, int > >::iterator vi = ref_unmatched[ite->first].begin(); vi != ref_unmatched[ite->first].end(); ++vi )
				{
					int ov_1 = -1;
					int ov_2 = -1;
					getoverlap( subi->first, subi->second, vi->first, vi->second, ov_1, ov_2 );
					if ( ov_1 != -1 && ov_2 != -1 )
					{
						unmatched.push_back( make_pair( ov_1, ov_2 ) );
					}
				}
			}

			vector< pair<int, int > > repeated;
			for ( map< pair<int, int >, Repeat_id >::iterator ri = ass_bank.ass_subject.Contigs[ite->first].repeat.begin();
				ri != ass_bank.ass_subject.Contigs[ite->first].repeat.end(); ++ri )
			{
				int ov_1 = -1;
				int ov_2 = -1;
				getoverlap( subi->first, subi->second, ri->first.first, ri->first.second, ov_1, ov_2 );
				if ( ov_1 != -1 && ov_2 != -1 )
				{
					repeated.push_back( make_pair( ov_1, ov_2 ) );
				}
			}

			vector< pair<int, int > > bothfea;
			bothfea = unmatched;
			bothfea.insert( bothfea.end(), repeated.begin(), repeated.end() );
			mergerange( bothfea );

			vector< pair< int, int > > nofea;
			getomisrange( bothfea, *subi, nofea );

			if ( !unmatched.empty() )
			{
				outf<<"\tunmatched:";
				for ( size_t i = 0; i < unmatched.size(); ++i )
				{
					outf<<"("<<unmatched[i].first<<","<<unmatched[i].second<<")";
				}

			}
			if ( !repeated.empty() )
			{
				outf<<"\trepeat:";
				for ( size_t i = 0; i < repeated.size(); ++i )
				{
					outf<<"("<<repeated[i].first<<","<<repeated[i].second<<")";
				}
			}
			if ( !nofea.empty() )
			{
				outf<<"\tno_feature:";
				for ( size_t i = 0; i < nofea.size(); ++i )
				{
					outf<<"("<<nofea[i].first<<","<<nofea[i].second<<")";
				}
			}
			outf<<endl;
		}
	}
	for ( map< Ctg_id, vector< pair<int, int > > >::iterator ite = qry_unmerged.begin(); ite != qry_unmerged.end(); ++ite )
	{
		outf<<">qry_"<<ass_bank.ass_query.Contigs[ite->first].name<<" "<<ass_bank.ass_query.Contigs[ite->first].length<<endl;
		for ( vector< pair<int, int > >::iterator subi = ite->second.begin(); subi != ite->second.end(); ++subi )
		{
			outf<<subi->first<<","<<subi->second;
			vector< pair<int, int > > unmatched;
			if ( qry_unmatched.find( ite->first ) != qry_unmatched.end() )
			{
				for ( vector< pair<int, int > >::iterator vi = qry_unmatched[ite->first].begin(); vi != qry_unmatched[ite->first].end(); ++vi )
				{
					int ov_1 = -1;
					int ov_2 = -1;
					getoverlap( subi->first, subi->second, vi->first, vi->second, ov_1, ov_2 );
					if ( ov_1 != -1 && ov_2 != -1 )
					{
						unmatched.push_back( make_pair( ov_1, ov_2 ) );
					}
				}
			}

			vector< pair<int, int > > repeated;
			for ( map< pair<int, int >, Repeat_id >::iterator ri = ass_bank.ass_query.Contigs[ite->first].repeat.begin();
				ri != ass_bank.ass_query.Contigs[ite->first].repeat.end(); ++ri )
			{
				int ov_1 = -1;
				int ov_2 = -1;
				getoverlap( subi->first, subi->second, ri->first.first, ri->first.second, ov_1, ov_2 );
				if ( ov_1 != -1 && ov_2 != -1 )
				{
					repeated.push_back( make_pair( ov_1, ov_2 ) );
				}
			}

			vector< pair<int, int > > bothfea;
			bothfea = unmatched;
			bothfea.insert( bothfea.end(), repeated.begin(), repeated.end() );
			mergerange( bothfea );

			vector< pair< int, int > > nofea;
			getomisrange( bothfea, *subi, nofea );

			if ( !unmatched.empty() )
			{
				outf<<"\tunmatched:";
				for ( size_t i = 0; i < unmatched.size(); ++i )
				{
					outf<<"("<<unmatched[i].first<<","<<unmatched[i].second<<")";
				}

			}
			if ( !repeated.empty() )
			{
				outf<<"\trepeat:";
				for ( size_t i = 0; i < repeated.size(); ++i )
				{
					outf<<"("<<repeated[i].first<<","<<repeated[i].second<<")";
				}
			}
			if ( !nofea.empty() )
			{
				outf<<"\tno_feature:";
				for ( size_t i = 0; i < nofea.size(); ++i )
				{
					outf<<"("<<nofea[i].first<<","<<nofea[i].second<<")";
				}
			}
			outf<<endl;
		}
	}
}

